﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using SMS.Entity;
using SMS.Exeception;

namespace SMS.DAL
{
    public class StudentOperations
    {
        public static int InsertStudent(Student stud)
        {
            int rowsAffected = 0;

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_InsertStudent_115022";

                cmd.Parameters.AddWithValue("@scode", stud.StudCode);
                cmd.Parameters.AddWithValue("@sname", stud.StudName);
                cmd.Parameters.AddWithValue("@dcode", stud.DeptCode);
                cmd.Parameters.AddWithValue("@dob", stud.DOB);
                cmd.Parameters.AddWithValue("@address", stud.Address);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int UpdateStudent(Student stud)
        {
            int rowsAffected = 0;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_UpdateStudent_115022";

                cmd.Parameters.AddWithValue("@scode", stud.StudCode);
                cmd.Parameters.AddWithValue("@dob", stud.DOB);
                cmd.Parameters.AddWithValue("@address", stud.Address);

                cmd.Connection.Open();
                rowsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rowsAffected;
        }

        public static int DeleteStudent(int scode)
        {
            int recordsAffected = 0;

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_DeleteStudent_115022";

                cmd.Parameters.AddWithValue("@scode", scode);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Student SearchStudent(int scode)
        {
            Student stud = null;

            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchStudent_115022";

                cmd.Parameters.AddWithValue("@scode", scode);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    stud = new Student();
                    stud.StudCode = Convert.ToInt32(dr["Student_Code"]);
                    stud.StudName = dr["Student_name"].ToString();
                    stud.DeptCode = Convert.ToInt32(dr["dept_code"]);
                    stud.DOB = Convert.ToDateTime(dr["Stuent_dob"]);
                    stud.Address = dr["Student_Address"].ToString();
                }
                else
                {
                    throw new StudentException("Student not avaialble with code : " + scode);
                }
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        public static List<Student> DisplayStudent()
        {
            List<Student> studList = null;

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_DisplayStudent_115022";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    studList = new List<Student>();

                    while (dr.Read())
                    {
                        Student stud = new Student();
                    
                        stud.StudCode = Convert.ToInt32(dr["Student_Code"]);
                        stud.StudName = dr["Student_name"].ToString();
                        stud.DeptCode = Convert.ToInt32(dr["dept_code"]);
                        stud.DOB = Convert.ToDateTime(dr["Stuent_dob"]);
                        stud.Address = dr["Student_Address"].ToString();

                        studList.Add(stud);
                    }
                }
                else
                    throw new StudentException("Student Details not Available");
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
    }
}
