﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exeception;
using SMS.BL;


namespace SMS.PL
{
    public partial class SearchStudent : System.Web.UI.Page
    {
        static List<Student> studList = null;
       // static string s;
        protected void Page_Load(object sender, EventArgs e)
        {
            
                studList = StudentValidations.DisplayStudent();
            if(!IsPostBack)
            {
                if (studList.Count > 0)
                {

                    dplistcode.DataSource = studList;
                    dplistcode.DataMember = "StudCode";
                    dplistcode.DataValueField = "StudCode";
                    dplistcode.DataBind();
                    //gvStudent.DataSource = studList;
                    //gvStudent.DataBind();
                }
            }
               
            

          
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {

                int studId = int.Parse(dplistcode.SelectedItem.ToString());
               // int studId = Convert.ToInt32(txtcode.Text);

                //Student stud = StudentValidation.SearchStudent(studCode);
               
                Student s = StudentValidations.SearchStudent(studId);
                
                
                if (s != null)
                {
                    List<Student> slist = new List<Student>();
                    //slist = StudentValidations.DisplayStudent();
                    slist.Add(s);
                    gvStudent.DataSource = slist;
                    gvStudent.DataBind();

                }
                else
                    throw new StudentException("Student Details Not Available");
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void dplistcode_SelectedIndexChanged(object sender, EventArgs e)
        {
            //DropDownList ddl = (DropDownList)sender;
            //n = int.Parse(ddl.SelectedItem.Text);
            //dplistcode.DataSource = studList;
            //dplistcode.DataMember = "StudCode";
            //dplistcode.DataValueField = "StudCode";
           
           
        }
    }
}