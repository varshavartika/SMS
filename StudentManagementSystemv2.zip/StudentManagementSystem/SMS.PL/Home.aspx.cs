﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exeception;
using SMS.BL;

namespace SMS.PL
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
                lblWelcome.Text = "Welcome " + Session["user"].ToString();
                Master.Logout = true;
                Master.Menu = true;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }

            try
            {
                List<Student> studList = StudentValidations.DisplayStudent();

                if (studList.Count > 0)
                {
                    gvStudent.DataSource = studList;
                    gvStudent.DataBind();
                }
                else
                    throw new StudentException("Student Details Not Available");
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}