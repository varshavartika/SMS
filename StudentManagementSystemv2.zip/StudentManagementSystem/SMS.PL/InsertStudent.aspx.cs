﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exeception;
using SMS.BL;

namespace SMS.PL
{
    public partial class InsertStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (Session["user"] != null)
            //{
            //    lblWelcome.Text = "Welcome " + Session["user"].ToString();
            //    Master.Logout = true;
            //    Master.Menu = true;
            //}
            //else
            //{
            //    Response.Redirect("Login.aspx");
            //}
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Student s = new Student();

                s.StudCode = Convert.ToInt32(txtcode.Text);
                s.StudName = txtname.Text;
                s.DeptCode = Convert.ToInt32(txtdep.Text);
                s.DOB = Convert.ToDateTime(txtdob.Text);
                s.Address= txtaddress.Text;

                int recordsAffected = StudentValidations.InsertStudent(s);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('" +"Inserted"+ "');</script>");
                }
                else
                    throw new StudentException("Student Details Not Available");
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}