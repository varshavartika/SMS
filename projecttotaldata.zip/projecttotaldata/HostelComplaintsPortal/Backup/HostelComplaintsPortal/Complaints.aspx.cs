﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace HostelComplaintsPortal
{
    public partial class Complaints : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
             
            }

        }
        string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
             SqlConnection con = new SqlConnection(connn);
             SqlCommand cmd = new SqlCommand("insert into ComplaintTable(regno,MobNo,RoomNo,Wing,HostelName,CmpCatgy,Complaint) values (@regno,@MobNo,@RoomNo,@Wing,@HostelName,@CmpCatgy,@Complaint)", con);

                cmd.Parameters.AddWithValue("@regno", txtrgno.Text);
                cmd.Parameters.AddWithValue("@MobNo", txtMobNo.Text);
                cmd.Parameters.AddWithValue("@RoomNo", txtroomno.Text);
                cmd.Parameters.AddWithValue("@Wing", txtWing.Text);


                cmd.Parameters.AddWithValue("@HostelName", ddlHostelName.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@CmpCatgy", dllCpnct.SelectedItem.Text);
                cmd.Parameters.AddWithValue("@Complaint", txtcomplt.Text);
                
                con.Open();
                int x = 0;
                x = cmd.ExecuteNonQuery();
                if (x > 0)
                {


                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('submit Successfully');", true);
                  

                }

            
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Please Select Designation!!');", true);
            }

            con.Close();
        }

    }
}