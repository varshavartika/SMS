﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace HostelComplaintsPortal
{
    public partial class ComplaintStatus : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {

            }
        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand("SELECT * FROM ComplaintTable WHERE regno='" + TextBox2.Text + "'", con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Label1.Text = ds.Tables[0].Rows[0][8].ToString();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Complaint Solve');", true);
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Complaint Not Solve');", true);
            }
        }

    }
}
    
