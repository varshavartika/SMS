﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;

namespace HostelComplaintsPortal
{
    public partial class AdminShowComplaintPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {



                string conn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                SqlConnection con = new SqlConnection(conn);
                SqlCommand cmd = new SqlCommand("SELECT * FROM ComplaintTable", con);
                con.Open();
                DataSet ds = new DataSet();
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                GridView2.DataSource = ds.Tables[0];
                GridView2.DataBind();
                con.Close();
                //GridView1.Visible = true;



            }
        }
        public void gridBind()
        {
            string conn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("SELECT * FROM ComplaintTable", con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            GridView2.DataSource = ds.Tables[0];
            GridView2.DataBind();
            con.Close();
        }

        protected void GridView2_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Submit")
            {
                GridViewRow row = (GridViewRow)(((Button)e.CommandSource).NamingContainer);
                TextBox txtDT = (TextBox)row.FindControl("txtComplaintSolveStatus");
         
                  Label lblcmid = (Label)row.FindControl("lblComplientId");
                  string conn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
                  SqlConnection con = new SqlConnection(conn);
                  SqlCommand cmd = new SqlCommand("update ComplaintTable set ComplainStatus=@ComplainStatus where ComplientId='" + lblcmid.Text + "'", con);
                  cmd.Parameters.AddWithValue("@ComplainStatus", txtDT.Text);
                
                con.Open();
                int i = cmd.ExecuteNonQuery();
                gridBind();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('updated Successfully');", true);
             
                
            }
        }
    }
}