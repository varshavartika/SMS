﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace HostelComplaintsPortal
{
    public partial class LoginPage : System.Web.UI.Page
    {
        string Islogin = "0";
        DataSet ds;
        string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session.Abandon();

                // FindUserName();
            }

        }

        public void ConnectionDatabse()
        {

            SqlConnection con = new SqlConnection(connn);

        }
        public void GetUserDetails()
        {
            //string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand("SELECT UserName,Password FROM LoginTable ", con);
            con.Open();
            ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //Session["Userdata"] = ds.Tables];
            if (ds.Tables[0].Rows.Count > 0)
            {

                Session["Userdata"] = ds;
                Session["username"] = ds.Tables[0].Rows[0][0].ToString();
                Session["LOGIN_TYPE"] = ds.Tables[0].Rows[0][1].ToString();

            }
            else
            {

            }




        }



        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Regs.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand("SELECT UserName,Password FROM LoginTable WHERE UserName='" + txtuserid.Text + "' and Password='" + txtpass.Text + "'", con);
            con.Open();
            ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {



                if (txtuserid.Text == "Admin")
                {

                    //Response.Redirect("profile.aspx");
                    Response.Redirect("AdminShowComplaintPage.aspx");
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('submit Successfully');", true);
                }
                else
                {
                    Response.Redirect("Complaints.aspx");
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('submit Successfully');", true);

                }


            }

            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('invalid username or password');", true);
            }
        }

        protected void LinkButton1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("Regs.aspx");
        }
    }
}