﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace storemanagmentsystem
{
    public partial class Regs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
               
                // FindUserName();
            }

        }
        string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;


        protected void btnRegister_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connn);

            SqlCommand cmd = new SqlCommand("insert into LoginTable(Name,StudId,EmailId,UserName,Password,MobileNo) values (@Name,@StudId,@EmailId,@UserName,@Password,@MobileNo)", con);


                cmd.Parameters.AddWithValue("@Name", txtName.Text);
                cmd.Parameters.AddWithValue("@StudId", txtstId.Text);
                cmd.Parameters.AddWithValue("@EmailId", txtEMAIL_ID.Text);


                cmd.Parameters.AddWithValue("@UserName", TxtUSER_NAME.Text);
                cmd.Parameters.AddWithValue("@Password", txtPASSWORD.Text);
                //cmd.Parameters.AddWithValue("@CONFIRM_PASSWORD", txtCONFIRM_PASSWORD.Text);
                cmd.Parameters.AddWithValue("@MobileNo", txtCONTACT_NO.Text);
               
                con.Open();
                int x = 0;
                x = cmd.ExecuteNonQuery();
                if (x > 0)
                {


                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('submit Successfully');", true);
                    Response.Redirect("LoginPage.aspx");

                }


            con.Close();
            //gridBind();
        }
       
       

     

    }
}