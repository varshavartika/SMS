﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exeception;
using SMS.BL;

namespace SMS.PL
{
    public partial class UpdateStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    Student s = new Student();

            //    s.StudCode = Convert.ToInt32(txtcode.Text);
            //    s.StudName = txtname.Text;
            //    s.DeptCode = Convert.ToInt32(txtdep.Text);
            //    s.DOB = Convert.ToDateTime(txtdob.Text);
            //    s.Address = txtaddress.Text;

            //    int recordsAffected = StudentValidations.UpdateStudent(s);

            //    if (recordsAffected > 0)
            //    {
            //        Response.Write("<script>alert('" + "updated" + "');</script>");
            //        List<Student> studlist = new List<Student>();
            //        studlist = StudentValidations.DisplayStudent();
            //    }
            //    else
            //        throw new StudentException("Student Details Not Available");
               
            //}
            //catch (StudentException ex)
            //{
            //    Response.Write("<script>alert('" + ex.Message + "');</script>");
            //}
            //catch (SystemException ex)
            //{
            //    Response.Write("<script>alert('" + ex.Message + "');</script>");
            //}
        }

        protected void btnSubmit_Click1(object sender, EventArgs e)
        {
            try
            {
                Student s = new Student();

                s.StudCode = int.Parse(txtcode.Text);
                s.StudName = txtname.Text;
                s.DeptCode = int.Parse(txtdep.Text);
                s.DOB = Convert.ToDateTime(txtdob.Text);
                s.Address = txtaddress.Text;

                int recordsAffected = StudentValidations.UpdateStudent(s);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('" + "updated" + "');</script>");
                    List<Student> studlist = new List<Student>();
                    studlist = StudentValidations.DisplayStudent();
                }
                else
                    throw new StudentException("Student Details Not Available");

            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}