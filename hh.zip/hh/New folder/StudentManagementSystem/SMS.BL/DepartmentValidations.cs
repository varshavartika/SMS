﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using SMS.Entity;
using SMS.Exeception;
using SMS.DAL;

namespace SMS.BL
{
   public class DepartmentValidations
    {
   
      static List<Department> deptList = null;

       public DepartmentValidations()
       {
          
           deptList = new List<Department>();
       }
       public  static List<Department> GetAll()
       {
           try
           {
             deptList = new List<Department>();
             deptList = DepartmentOperations.SelectAll();

           }
           catch (SystemException ex)
           {
               throw ex;
           }
           catch (DepartmentException ex)
           {
               throw ex;
           }


           return deptList;
       }
    }
}
