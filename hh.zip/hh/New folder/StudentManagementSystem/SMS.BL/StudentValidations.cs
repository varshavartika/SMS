﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;
using SMS.Exeception;
using SMS.DAL;

namespace SMS.BL
{
    public class StudentValidations
    {
        public static int InsertStudent(Student stud)
        {
            int recordsAffected;

            try 
            {
                recordsAffected = StudentOperations.InsertStudent(stud);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int UpdateStudent(Student stud)
        {
            int recordsAffected;

            try
            {
                recordsAffected = StudentOperations.UpdateStudent(stud);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static int DeleteStudent(int scode)
        {
            int recordsAffected;

            try
            {
                recordsAffected = StudentOperations.DeleteStudent(scode);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public static Student SearchStudent(int scode)
        {
            Student stud = null;

            try
            {
                stud = StudentOperations.SearchStudent(scode);
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        public static List<Student> DisplayStudent()
        {
            List<Student> studList = null;

            try 
            {
                studList = StudentOperations.DisplayStudent();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
    }
}
