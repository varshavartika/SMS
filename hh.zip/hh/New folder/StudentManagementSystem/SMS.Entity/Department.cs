﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Entity
{
    public class Department
    {
        public int DeptCode { get; set; }
        public string DeptName { get; set; }
    }
}
