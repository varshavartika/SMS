﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exeception
{
    public class DepartmentException :ApplicationException
    {
        public DepartmentException() : base ()
        {

        }

        public DepartmentException(string message)
           : base(message)
       {

       }
    }
}
