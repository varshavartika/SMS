﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using SMS.Entity;
using SMS.Exeception;

namespace SMS.DAL
{
    public class DepartmentOperations
    {
        public static List<Department> SelectAll()
        {
            List<Department> dept = null;
            try
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SelectDeptCode";

                cmd.Connection.Open();

                SqlDataReader dr = cmd.ExecuteReader();




                dept = new List<Department>();

                while (dr.Read())
                {
                    Department dep = new Department();

                    dep.DeptCode = Convert.ToInt32(dr["Dept_Code"]);
                    dep.DeptName = dr["Dept_Name"].ToString();
                    dept.Add(dep);
                }


                cmd.Connection.Close();
            }



            catch (DepartmentException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return dept;
        }
    }
}



