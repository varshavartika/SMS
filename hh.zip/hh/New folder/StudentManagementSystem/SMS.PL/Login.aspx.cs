﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exeception;
using SMS.BL;

namespace SMS.PL
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try 
            {
                User user = new User();
                user.UserName = txtUserName.Text;
                user.Password = txtPassword.Text;

                string username = UserValidations.ValidateUser(user);

                if (username == String.Empty || username == null)
                {
                    lblError.Text = "Invalid Username / Password";
                }
                else 
                {
                    Session["user"] = username;
                    Response.Redirect("Home.aspx");
                }
            }
            catch (UserException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}