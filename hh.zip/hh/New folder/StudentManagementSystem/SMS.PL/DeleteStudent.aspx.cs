﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using SMS.Entity;
using SMS.Exeception;
using SMS.BL;

namespace SMS.PL
{
    public partial class DeleteStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {

                Master.Logout = true;
                Master.Menu = true;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {

            try
            {
                int studid = int.Parse(txtStudCode.Text);

                int recordsAffected = StudentValidations.DeleteStudent(studid);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('" + "Deleted" + "');</script>");
                    List<Student> studlist = new List<Student>();

                    studlist = StudentValidations.DisplayStudent();

                    grdStudList.DataSource = studlist;
                    grdStudList.DataBind();
                }
                else
                    throw new StudentException("Student Details Not Available");
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }
    }
}