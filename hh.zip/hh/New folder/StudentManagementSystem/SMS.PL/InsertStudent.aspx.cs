﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using SMS.Entity;
using SMS.Exeception;
using SMS.BL;

namespace SMS.PL
{
    public partial class InsertStudent : System.Web.UI.Page
    {
         List<Department> deptList = null;
    

        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] != null)
            {
               
                Master.Logout = true;
                Master.Menu = true;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }


            if (!IsPostBack)
            {

                deptList = new List<Department>();
                deptList = DepartmentValidations.GetAll();
                ddlDeptCode.DataSource = deptList;
                ddlDeptCode.DataMember = "DeptCode";
                ddlDeptCode.DataValueField = "DeptCode";
                ddlDeptCode.DataBind();

            }

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            try
            {

                Student stud = new Student();

                stud.StudCode = Convert.ToInt32(txtStudCode.Text);
                stud.StudName = txtStudName.Text;
                stud.DeptCode = Convert.ToInt32(ddlDeptCode.Text);
                stud.DOB = Convert.ToDateTime(txtDOB.Text);
                stud.Address = txtAddress.Text;
                int recordsAffected = StudentValidations.InsertStudent(stud);

                if (recordsAffected > 0)
                {
                    Response.Write("<script>alert('" + "Inserted" + "');</script>");
                    clear();
                }
                else
                    throw new StudentException("Student Details Not Available");

                
            }

            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }

        }

        private void clear()
        {
            ddlDeptCode.Text = "";
            txtStudCode.Text = "";
            txtStudName.Text = "";
            txtDOB.Text = "";
            txtAddress.Text = "";
        }

        protected void btnExit_Click(object sender, EventArgs e)
        {
            Response.Redirect("Home.aspx");
        }
    }
}