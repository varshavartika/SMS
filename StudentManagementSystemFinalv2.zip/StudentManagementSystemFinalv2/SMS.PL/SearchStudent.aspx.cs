﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SMS.Entity;
using SMS.Exeception;
using SMS.BL;

namespace SMS.PL
{
    public partial class SearchStudent : System.Web.UI.Page
    {
        Student stud = new Student();

        protected void Page_Load(object sender, EventArgs e)
        {            

            ddlCode.DataSource = StudentValidations.DisplayStudent();
            ddlCode.DataTextField = "StudCode";
            ddlCode.DataBind();            

            if (Session["user"] != null)
            {

                Master.Logout = true;
                Master.Menu = true;
            }
            else
            {
                Response.Redirect("Login.aspx");
            }
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if(this.IsPostBack)
            {
                btnUpdate.Visible = true;
                btnDelete.Visible = true;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }

            int scode = Convert.ToInt32(txtStudCode.Text);

            //int scode = Convert.ToInt32(ddlCode.Text);        //for populating through DDL

            try 
            {
                    stud = StudentValidations.SearchStudent(scode);
 
                    txtName.Text = stud.StudName;
                    txtName.DataBind();
                    txtDeptCode.Text = stud.DeptCode.ToString();
                    txtDeptCode.DataBind();                  
                    txtDob.Text = stud.DOB.ToString();
                    txtDob.DataBind();                    
                    txtAddress.Text = stud.Address;
                    txtAddress.DataBind();
           
            }
            catch(StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch(SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }  
            
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            { 
                stud.StudCode = Convert.ToInt32(txtStudCode.Text);
                stud.StudName = txtName.Text;                
                stud.DeptCode = Convert.ToInt32(txtDeptCode.Text);
                stud.DOB = Convert.ToDateTime(txtDob.Text);
                stud.Address = txtAddress.Text;

                string str = Convert.ToString(StudentValidations.UpdateStudent(stud));
                int s;
                bool b = int.TryParse(str, out s);
                if(b)
                {
                    Response.Write("<script>alert('Student Updated Sucessfully');</script>");
                }
                else
                {
                    Response.Write("<script>alert('Record not Updated');</script>");
                }      
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {            
            try
            {
                string str = Convert.ToString(StudentValidations.DeleteStudent(Convert.ToInt32(txtStudCode.Text)));
                int s;
                bool b = int.TryParse(str, out s);
                if (b)
                {
                    Response.Write("<script>alert('Student Deleted Sucessfully');</script>");
                }
                else
                {
                    Response.Write("<script>alert('Record not Deleted');</script>");
                }       
            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }        

        protected void ddlCode_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (this.IsPostBack)
            {
                btnUpdate.Visible = true;
                btnDelete.Visible = true;
                btnUpdate.Enabled = true;
                btnDelete.Enabled = true;
            }

            int scode = Convert.ToInt32(ddlCode.Text);

            try
            {
                stud = StudentValidations.SearchStudent(scode);

                if (!IsPostBack)
                {
                    StudentValidations.SearchStudent(scode);
                }

                txtStudCode.Text = stud.StudCode.ToString();
                txtStudCode.DataBind();
                txtName.Text = stud.StudName;
                txtName.DataBind();
                txtDeptCode.Text = stud.DeptCode.ToString();
                txtDeptCode.DataBind();
                txtDob.Text = stud.DOB.ToString();
                txtDob.DataBind();
                txtAddress.Text = stud.Address;
                txtAddress.DataBind();

            }
            catch (StudentException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }    
  
        }
    }
}