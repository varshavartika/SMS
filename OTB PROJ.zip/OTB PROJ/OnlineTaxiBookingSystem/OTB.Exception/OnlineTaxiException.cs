﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OTB.Exception
{
    public class OnlineTaxiException : ApplicationException
    {
        public OnlineTaxiException():base()
        {

        }

        public OnlineTaxiException(string message):base(message)
        {

        }
    }
}
