﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OTB.Entity;
using OTB.BL;
using OTB.Exception;

namespace Taxi
{
    /// <summary>
    /// Interaction logic for ServicePg.xaml
    /// </summary>
    public partial class ServicePg : Window
    {
        TaxiValidations tv = null;
        Training_13Dec17_Hinjawadi_PuneEntities context = null;
        
        public ServicePg()
        {
            InitializeComponent();
            tv = new TaxiValidations();
            context = new Training_13Dec17_Hinjawadi_PuneEntities();
        }

        private void btnmicro_Click(object sender, RoutedEventArgs e)
        {
            //try
            //{
            //    string type = "Micro";

            //    //Student stud = StudentValidation.SearchStudent(studCode);
               
            //    List<Taxie> t = new List<Taxie>();
            //      t=  tv.SearchTaxi(type);
            //    if (t != null)
            //    {
            //        dgvtaxisearch.ItemsSource = t;
            //        dgvtaxisearch.DataContext = t;

            //    }

            //    else
            //        throw new OnlineTaxiException("Employee record not found");
            //}
            //catch (OnlineTaxiException ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
            //catch (SystemException ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}

            var query = from t in context.Taxi_OTB.Where(t => t.Taxi_Type == "Micro")
                        select t;

            dgvtaxisearch.ItemsSource = query.ToList();
        }

        private void btnmini_Click(object sender, RoutedEventArgs e)
        {
            var query = from t in context.Taxi_OTB.Where(t => t.Taxi_Type == "Mini")
                        select t;

            dgvtaxisearch.ItemsSource = query.ToList();
        }

        private void btnprime_Click(object sender, RoutedEventArgs e)
        {
            var query = from t in context.Taxi_OTB.Where(t => t.Taxi_Type =="Prime")
                        select t;

            dgvtaxisearch.ItemsSource = query.ToList();
        }

        private void btnsuv_Click(object sender, RoutedEventArgs e)
        {
            var query = from t in context.Taxi_OTB.Where(t => t.Taxi_Type == "SUV")
                        select t;

            dgvtaxisearch.ItemsSource = query.ToList();
        }

        private void btnBookCab_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult res = MessageBox.Show("Login Required!", "quit", MessageBoxButton.OKCancel);
            switch (res)
            {
                case MessageBoxResult.OK:

                    this.Close();
                   
                  Window1 sign = new Window1();
                    sign.Show();
                    break;
              case MessageBoxResult.Cancel:
                   break;
            }
        }
    }
}
