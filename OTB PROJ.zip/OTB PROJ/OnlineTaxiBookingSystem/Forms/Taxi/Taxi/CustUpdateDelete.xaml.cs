﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OTB.Entity;
using OTB.Exception;
using OTB.BL;


namespace Taxi
{
    /// <summary>
    /// Interaction logic for CustUpdateDelete.xaml
    /// </summary>
    public partial class CustUpdateDelete : Window
    {
        TaxiValidations bal = null;
        Customer cust = new Customer();
        List<Customer> custlist = null;
        public CustUpdateDelete()
        {
            InitializeComponent();
            bal = new TaxiValidations();
            custlist = new List<Customer>();
            custlist = bal.RetrieveCustomer();
            cbID.ItemsSource = custlist;
            cbID.DisplayMemberPath = "CustomerID";
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Customer cust = new Customer();
                cust.CustomerID = int.Parse(cbID.Text);
                cust.CustomerName = txtcustname.Text;
                cust.EmailID = txtcuemailid.Text;
                cust.PhoneNumber = txtcuphno.Text;
                cust.CAddress = txtcuaddress.Text;


                int recordsAffected = bal.ModifyCustomer(cust);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Customer details updated!");
                    bal.RetrieveCustomer();
                    this.Close();
                }
                //MessageBox.Show("Customer Details Modified!");
                


            }

            catch (OnlineTaxiException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int custid = int.Parse(cbID.Text);

                int recordsAffected = bal.DeleteCustomer(custid);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record deleted successfully");
                }
                else
                    throw new OnlineTaxiException("Record not deleted");
            }
            catch (OnlineTaxiException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cbID_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           
            
        }

        private void btnSearchCust_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int id = Convert.ToInt32(cbID.Text);

                Customer cust = bal.SearchCustomer(id);
                if (cust != null)
                {
                    txtcustname.Text = cust.CustomerName;
                    txtcuemailid.Text = cust.EmailID.ToString();
                    txtcuphno.Text = cust.PhoneNumber.ToString();
                    txtcuaddress.Text = cust.CAddress.ToString();
                }
                else
                    throw new OnlineTaxiException("Customer record not found");
            }
            catch (OnlineTaxiException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
