﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OTB.BL;
using OTB.Entity;
using OTB.Exception;

namespace Taxi
{
    /// <summary>
    /// Interaction logic for CustomerDash.xaml
    /// </summary>
    public partial class CustomerDash : Window
    {
        TaxiValidations bal = null;
        List<Customer> custlist = null;
        List<Roaster> rst = null;
       List<Booking> bookinglist = null;
       Booking bk = null;
       Training db = null;
     //  int n;
        //Training_13Dec17_Hinjawadi_PuneEntities1 dbContext = null;
        public CustomerDash()
        {
            InitializeComponent();
            bal = new TaxiValidations();
            custlist = new List<Customer>();
            rst = new List<Roaster>();
            rst = bal.RetrieveRoster();
            custlist = bal.RetrieveCustomer();
            bookinglist = new List<Booking>();
            db = new Training();
            bk = new Booking();
           
           // dbContext = new Training_13Dec17_Hinjawadi_PuneEntities1();
            //var res = from p in dbContext.Feedback_OTB
            //          select p;
            
            cbSelectCustID.ItemsSource = custlist;
            cbSelectCustID.DataContext = "CustomerID";
            dgvDriverHistory.ItemsSource = rst;

            cbFeedbackCustID.ItemsSource = custlist;
            cbFeedbackCustID.DataContext = "CustomerID";
        }

        private void btnHistory_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            //try
            //{
                DateTime date = DateTime.Now;
                Booking booking = new Booking();
                booking.CustomerID = Convert.ToInt32(cbSelectCustID.Text);
                booking.SourceAddress = cbFrom.Text;
                booking.DestinationAddress = cbTo.Text;
                booking.TripDate = Convert.ToDateTime(whendp.Text);
                booking.BookingDate = date;
                booking.StartTime = txtstart.Text;
                booking.EndTime = txtend.Text;
                //int recordsAffected = bal.InsertBooking(booking);

                if (bal.InsertBooking(booking))
                {
                    MessageBox.Show("Record inserted successfully");
                    //  MessageBox.Show("Confirm Booking?");
                    BookingSummary bs = new BookingSummary();
                    bs.Show();
                }
                else
                {
                    //throw new OnlineTaxiException("Record inserted");
                    MessageBoxResult res = MessageBox.Show("Record inserted", "calculate fare", MessageBoxButton.OK);
                    switch (res)
                    {
                        case MessageBoxResult.OK:
                           
                           // BookingSummary bs = new BookingSummary();
                           // bs.Show();
                            this.Close();
                            break;
                    }



                }
            //}

            //catch (OnlineTaxiException ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
            //catch (SystemException ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}

            
        }

        private void btnHistory_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            //Feedback_OTB fb = new Feedback_OTB();

            ////fb.CustomerID =(int)txtcustid.text;
            //fb.fmessage = rtxtfeedback.Text;
            //fb.fmessage = cbFeedbackCustID.Text;
            //dbContext.Feedback_OTB.Add(fb);
            //dbContext.SaveChanges(); // internally it is using disconnected architecture  
            //datagrid1.ItemsSource = dbContext.Product1_142746.ToList();
            MessageBox.Show("Feedback inserted successfully");
            MessageBoxResult res = MessageBox.Show("Feedback inserted successfully", "quit", MessageBoxButton.OK);
            switch (res)
            {
                case MessageBoxResult.OK:
                    //BookingSummary bs = new BookingSummary();
                   // bs.Show();
                    this.Close();
                    break;
            }
        }

        private void show_Click(object sender, RoutedEventArgs e)
        {
            int n=Convert.ToInt32(cbSelectCustID.Text);
            var qr = from b in db.BookingNN_OTB
                     where b.CustomerID == n
                     select b;
            dgvBookinSummary.ItemsSource = qr.ToList();
            //dgvBookinSummary.DataContext = "CustomerID";
        }
    }
}
