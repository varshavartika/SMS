﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Taxi
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<Window1>().Any())
            {
                Application.Current.Windows.OfType<Window1>().First().Activate();

                //MessageBox.Show("Window Already Open");
            }
            else
            {

                Window1 W = new Window1();
                W.Show();

            }
            //Window1 W = new Window1();
            //W.Show();
        }

        private void BtnServices_Click(object sender, RoutedEventArgs e)
        {
            if (Application.Current.Windows.OfType<ServicePg>().Any())
            {
                Application.Current.Windows.OfType<ServicePg>().First().Activate();

                //MessageBox.Show("Window Already Open");
            }
            else
            {

                ServicePg pg = new ServicePg();
                pg.Show();

            }
            
        }
    }
}
