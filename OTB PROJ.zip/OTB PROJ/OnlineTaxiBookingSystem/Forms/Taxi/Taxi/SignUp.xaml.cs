﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OTB.Entity;
using OTB.Exception;
using OTB.BL;
namespace Taxi
{
    /// <summary>
    /// Interaction logic for SignUp.xaml
    /// </summary>
    public partial class SignUp : Window
    {

        TaxiValidations bal= null;
        List<Customer> cust1= null;
    
        public SignUp()
        {
            InitializeComponent();
            bal= new TaxiValidations();
        }

        private void btnregister_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Customer c = new Customer();
                c.CustomerName = txtcustname.Text;
                c.CAddress = txtaddress.Text;
              
                c.EmailID = txtemail.Text;
                c.PhoneNumber = txtphno.Text;
                c.CPassword = pbCust.Password;

               if (bal.InsertCustomer(c))
                {

                    MessageBox.Show("Customer Inserted");

                }

                MessageBox.Show("Registered Successfully!");

            }

            catch (OnlineTaxiException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
