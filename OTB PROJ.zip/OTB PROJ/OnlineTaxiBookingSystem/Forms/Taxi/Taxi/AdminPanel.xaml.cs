﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OTB.BL;
using OTB.Entity;
using OTB.Exception;

namespace Taxi
{
    /// <summary>
    /// Interaction logic for AdminPanel.xaml
    /// </summary>
    public partial class AdminPanel : Window
    {
        TaxiValidations bal = null;
        List<Employee> emplist = null;
        List<Roaster> rstlist = null;
        List<Customer> custlist = null;
        Training_13Dec17_Hinjawadi_PuneEntities1 dbContext = null;
        Training_13Dec17_Hinjawadi_PuneEntities2 dbContext2 = null;
        Training_13Dec17_Hinjawadi_PuneEntities4 dbContext3 = null;

        public AdminPanel()
        {
            InitializeComponent();
            bal = new TaxiValidations();
            dbContext = new Training_13Dec17_Hinjawadi_PuneEntities1();
            dbContext2 = new Training_13Dec17_Hinjawadi_PuneEntities2();
            dbContext3 = new Training_13Dec17_Hinjawadi_PuneEntities4();
            emplist = new List<Employee>();
            rstlist = new List<Roaster>();
            rstlist = bal.RetrieveRoster();
            var res = from p in dbContext.Feedback_OTB
                      select p;
            dgfeedback.ItemsSource = res.ToList();
            cbfeedback.ItemsSource = res.ToList();
            cbfeedback.DataContext = "FeedbackID";
        }

        private void btnregister_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Employee emp = new Employee();
                emp.EmployeeName = txtempname.Text;
                emp.Designation = txtdesg.Text;
                emp.PhoneNumber = txtphno.Text;
                emp.EmailID = txtemailid.Text;
                emp.Address = txtaddress.Text;
                emp.DrivingLicenseNumber = txtdlno.Text;
                emp.EPassword = pbPassword.Password;
                if (bal.InsertEmployee(emp))
                {

                    MessageBox.Show("Employee Inserted");

                }

                MessageBox.Show("Registered Successfully!");

            }

            catch (OnlineTaxiException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }



        private void btnmicro_Click(object sender, RoutedEventArgs e)
        {
            if(rbtnEmp.IsChecked==true)
            {
                emplist = bal.RetrieveEmployee();
                dgvtaxisearch.ItemsSource = emplist;
                dgvtaxisearch.DataContext = emplist;
            }
            else if(rbtnCust.IsChecked==true)
            {
                custlist = new List<Customer>();
                custlist = bal.RetrieveCustomer();
                dgvtaxisearch.ItemsSource = custlist;
                dgvtaxisearch.DataContext = custlist;
            }
            
        }

        private void btnsuv_Click(object sender, RoutedEventArgs e)
        {
            if(rbtnEmp.IsChecked== true)
            {
                NewEmpReg n = new NewEmpReg();
                n.Show();
            }
            else if(rbtnCust.IsChecked==true)
            {
                CustUpdateDelete c = new CustUpdateDelete();
                c.Show();
            }
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Roaster rst = new Roaster();
                rst.EmployeeID = Convert.ToInt32(txtempid.Text);
                rst.FromDate = Convert.ToDateTime(txtfromdate.Text);
                rst.ToDate = Convert.ToDateTime(txttodate.Text);
                rst.InTime = Convert.ToDateTime(txtintime.Text);
                rst.OutTime = Convert.ToDateTime(txtouttime.Text);

                int recordsAffected = bal.InsertEmployeeRoster(rst);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record inserted successfully");

                }
                else
                    throw new OnlineTaxiException("Record not inserted");


            }

            catch (OnlineTaxiException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void cbempid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Roaster rst = new Roaster();
                rst.EmployeeID = Convert.ToInt32(txtempid.Text);
                rst.FromDate = Convert.ToDateTime(txtfromdate.Text);
                rst.ToDate = Convert.ToDateTime(txttodate.Text);
                rst.InTime = Convert.ToDateTime(txtintime.Text);
                rst.OutTime = Convert.ToDateTime(txtouttime.Text);



                int recordsAffected = bal.ModifyRoster(rst);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully");

                }
                else
                    throw new OnlineTaxiException("Record not updated");
            }
            catch (OnlineTaxiException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int empid = int.Parse(txtempid.Text);

                int recordsAffected = bal.DeleteRoster(empid);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully");

                }
                else
                    throw new OnlineTaxiException("Record not deleted");
            }
            catch (OnlineTaxiException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {
            //CUSTOMER ENTITY CLASS INSTANCE
            try
            {
                FeedbackReply_OTB f = new FeedbackReply_OTB();
                f.f1message = txtfeedback.Text;
                dbContext2.FeedbackReply_OTB.Add(f);
                dbContext2.SaveChanges();
                MessageBox.Show("Successfully Replied");
                Clear();
                // internally it is using disconnect
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void Clear()
        {
            txtfeedback.Text = "";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (rbtndaily.IsChecked == true)
            {
                DateTime date = DateTime.Today;
                var res = from r in dbContext3.EmployeeRoster_OTBN
                          where
                              (r.FromDate == date)
                          select r;

                dgPrintRoster.ItemsSource = res.ToList();
            }
            if (rbtWeekly.IsChecked == true)
            {
               
                  DateTime date = DateTime.Today;
                 DateTime date1 = DateTime.Today.AddDays(-7);
                 DateTime date2 = DateTime.Today.AddDays(-6);
                 DateTime date3 = DateTime.Today.AddDays(-5);
                 DateTime date4 = DateTime.Today.AddDays(-4);
                 DateTime date5 = DateTime.Today.AddDays(-3);
                 DateTime date6 = DateTime.Today.AddDays(-2);
                 DateTime date7 = DateTime.Today.AddDays(-1);

              
                  var res = from r in dbContext3.EmployeeRoster_OTBN
                         
                            where (r.FromDate == date) || (r.FromDate == date1)|| (r.FromDate == date2)|| (r.FromDate == date3)|| (r.FromDate == date4)|| (r.FromDate == date5)|| (r.FromDate == date6)|| (r.FromDate == date7)
             
                            select r;
                  dgPrintRoster.ItemsSource = res.ToList();
            }
                if (rbtnannually.IsChecked == true)
                {
                    DateTime date = DateTime.Today;
                    DateTime date1=DateTime.Today.AddYears(-1);

                    var res=from r in dbContext3.EmployeeRoster_OTBN
                            where (r.FromDate>=date1)
                            select r;
                    dgPrintRoster.ItemsSource = res.ToList();
                }


            }


        }
    }


