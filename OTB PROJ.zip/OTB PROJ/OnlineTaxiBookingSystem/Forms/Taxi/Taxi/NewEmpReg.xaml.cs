﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OTB.Entity;
using OTB.BL;
using OTB.Exception;

namespace Taxi
{
    /// <summary>
    /// Interaction logic for NewEmpReg.xaml
    /// </summary>
    public partial class NewEmpReg : Window
    {
        TaxiValidations bal = null;
       
        public NewEmpReg()
        {
            InitializeComponent();
            bal = new TaxiValidations();
            List<Employee> emplist = new List<Employee>();
            emplist = bal.RetrieveEmployee();
            cbID.ItemsSource = emplist;
            cbID.DataContext = "EmployeeID";
            
        }


        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                Employee emp = new Employee();
                emp.EmployeeID = int.Parse(cbID.Text);
                emp.EmployeeName = txtempname.Text;
                emp.Designation = txtdesg.Text;
                emp.PhoneNumber = txtphno.Text;
                emp.EmailID = txtemailid.Text;
                emp.Address = txtaddress.Text;
                emp.DrivingLicenseNumber = txtdlno.Text;


                int recordsAffected = bal.ModifyEmployee(emp);

                if (recordsAffected > 0)
               
               
                {

                    MessageBox.Show("Customer Details Modified");

                }

                MessageBox.Show("Customer Details Modified!");

            }

            catch (OnlineTaxiException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int empid = int.Parse(cbID.Text);

                int recordsAffected = bal.DeleteEmployee(empid);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully");
                    
                    
                }
                else
                    throw new OnlineTaxiException("Record not deleted");
            }
            catch (OnlineTaxiException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
