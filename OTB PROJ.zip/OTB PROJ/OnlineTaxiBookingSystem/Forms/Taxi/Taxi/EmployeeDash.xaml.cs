﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OTB.BL;
using OTB.Entity;
using OTB.Exception;

namespace Taxi
{
    /// <summary>
    /// Interaction logic for EmployeeDash.xaml
    /// </summary>
    public partial class EmployeeDash : Window
    {
        TaxiValidations bal = null;
        List<Roaster> rstlist = null;
        List<Booking> bookinglist = null;
        public EmployeeDash()
        {
            InitializeComponent();
            bal = new TaxiValidations();
            bookinglist = new List<Booking>();
            rstlist = new List<Roaster>();
            rstlist = bal.RetrieveRoster();
            bookinglist = bal.RetrieveBooking();
            gdroaster.ItemsSource = rstlist;
            gdbookinglist.ItemsSource = bookinglist;
           

        }

        private void btnLogCount_Click(object sender, RoutedEventArgs e)
        {
            txtCountLog.Text = bookinglist.Count.ToString();
        }
    }
}
