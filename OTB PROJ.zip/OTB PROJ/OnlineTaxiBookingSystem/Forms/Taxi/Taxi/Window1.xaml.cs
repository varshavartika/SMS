﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using OTB.Entity;
using OTB.BL;

namespace Taxi
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        TaxiValidations bl = null;
        Training_13Dec17_Hinjawadi_PuneEntities5 dbcontext = null;
        Training_13Dec17_Hinjawadi_PuneEntities6 dbcontext1 = null;
  
        public Window1()
        {
            InitializeComponent();
            bl = new TaxiValidations();
            dbcontext = new Training_13Dec17_Hinjawadi_PuneEntities5();
            dbcontext1 = new Training_13Dec17_Hinjawadi_PuneEntities6();
           
        }

        private void btnsignin_Click(object sender, RoutedEventArgs e)
        {
            if (cbRole.Text == "Admin")
            {
                if (txtuserid.Text == "admin" && txtpass.Password == "admin")
                {
                    AdminPanel ap = new AdminPanel();
                    ap.Show();
                }
                else
                {
                    MessageBox.Show("Username and Pssword is not correct");
                    txtuserid.Text = "";
                    txtpass.Password = "";
                }

            }

            if (cbRole.Text == "Employee")
            {
                int n = Convert.ToInt32(txtuserid.Text);
                int d1;
                if (!int.TryParse(txtuserid.Text, out d1) || txtpass.Password == String.Empty)
                {
                    MessageBox.Show("Username and Password not provided!");

                }
                else
                {
                   
                    var res = (from emp in dbcontext.Employee_OTB
                               where emp.EmployeeID == n
                               select emp.EmployeeID).FirstOrDefault();

                    var res1 = (from emp in dbcontext.Employee_OTB
                                where emp.EPassword == txtpass.Password
                                select emp.EPassword).FirstOrDefault();


                    string s = res1;

                    if (Convert.ToBoolean(res) == true && s == null)
                    {
                        MessageBox.Show("Password is not correct");
                        txtuserid.Text = "";
                        txtpass.Password = "";
                    }

                    else if (Convert.ToBoolean(res) == true && res1.ToString() == txtpass.Password)
                    {
                        EmployeeDash d = new EmployeeDash();
                        d.Show();
                    }

                    else
                    {
                        MessageBox.Show("Username and Password is not correct");
                        txtuserid.Text = "";
                        txtpass.Password = "";
                    }


                }
               
            }


            if (cbRole.Text == "Customer")
            {
                int d1;
                if (!int.TryParse(txtuserid.Text, out d1) || txtpass.Password == String.Empty)
                {
                    MessageBox.Show("Username and Password not provided!");

                }
                else
                {
                    
                    var res = (from cust in dbcontext1.Customer_OTB
                               where cust.CustomerID.ToString() == txtuserid.Text
                               select cust.CustomerID).FirstOrDefault();

                    var res1 = (from cust in dbcontext1.Customer_OTB
                                where cust.CPassword == txtpass.Password
                                select cust.CPassword).FirstOrDefault();

                    string s = res1;
                    if (Convert.ToBoolean(res) == true && s == null)
                    {
                        MessageBox.Show(" Password is not correct");
                        txtuserid.Text = "";
                        txtpass.Password = "";
                    }

                else if (Convert.ToBoolean(res) == true && s == txtpass.Password)
                    {
                        CustomerDash d = new CustomerDash();
                        d.Show();
                    }
                    else
                    {
                        MessageBox.Show("Username and Password is not correct");
                        txtuserid.Text = "";
                        txtpass.Password = "";
                    }
                  
                }
            }
        }
               
               
                 

              
           
        

        private void BtnSignUp_Click(object sender, RoutedEventArgs e)
        {
            SignUp s = new SignUp();
            s.Show();
        }
    }
}
