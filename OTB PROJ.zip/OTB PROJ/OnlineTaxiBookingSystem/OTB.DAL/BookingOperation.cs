﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OTB.Entity;
using OTB.Exception;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;

namespace OTB.DAL
{
    public class BookingOperation
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        List<Booking> booklist = null;

        public BookingOperation()
        {
            string cnStr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
            cn = new SqlConnection(cnStr);
            booklist = new List<Booking>();
        }

        public bool InsertBooking(Booking book)
        {
            bool custInserted = false;

            try
            {

                cmd = new SqlCommand("USP_InsertBookingNN_OTB", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CustomerID", book.CustomerID);
                cmd.Parameters.AddWithValue("@TripDate", book.TripDate);
                cmd.Parameters.AddWithValue("@Booking_Date", book.BookingDate);
                cmd.Parameters.AddWithValue("@SourceAddress", book.SourceAddress);
                cmd.Parameters.AddWithValue("@DestinationAddress", book.DestinationAddress);
                cmd.Parameters.AddWithValue("@StartTime", book.StartTime);
                cmd.Parameters.AddWithValue("@EndTime", book.EndTime);

                cn.Open();
                cmd.ExecuteNonQuery();//for insert delete and update
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();

            }
            return custInserted;
        }

            //public static bool ModifyBooking(Booking booking)
            //{
            //    bool BookingModified = false;

            //    try
            //    {
            //        for (int i = 0; i < bookingList.Count; i++)
            //        {
            //            //Searching Booking
            //            if (bookingList[i].BookingID == booking.BookingID)
            //            {
            //                //Modifying Employee Details
            //                bookingList[i].CustomerID = booking.CustomerID;
            //                bookingList[i].TaxiID = booking.TaxiID;
            //                bookingList[i].BookingDate = booking.BookingDate;
            //                bookingList[i].TripDate = booking.TripDate;
            //                bookingList[i].StartTime = booking.StartTime;
            //                bookingList[i].EndTime = booking.EndTime;
            //                bookingList[i].SourceAddress = booking.SourceAddress;
            //                bookingList[i].DestinationAddress = booking.DestinationAddress;
            //                BookingModified = true;
            //            }
            //        }
            //    }
            //    catch (OnlineTaxiException ex)
            //    {
            //        throw ex;
            //    }
            //    catch (SystemException ex)
            //    {
            //        throw ex;
            //    }

            //    return BookingModified;
            //}

            //public static bool DeleteBooking(int bookingID)
            //{
            //    bool BookingDeleted = false;

            //    try
            //    {
            //        //Searching Employee
            //        Booking Booking = bookingList.Find(b => b.BookingID == bookingID);
            //        if (Booking != null)
            //        {
            //            //Removing Employee
            //            bookingList.Remove(Booking);
            //            BookingDeleted = true;
            //        }
            //        else
            //        {
            //            throw new OnlineTaxiException("Booking with id " + bookingID + " not found for deletion");
            //        }
            //    }
            //    catch (OnlineTaxiException ex)
            //    {
            //        throw ex;
            //    }
            //    catch (SystemException ex)
            //    {
            //        throw ex;
            //    }

            //    return BookingDeleted;
            //}

        public List<Booking> SearchBooking(int bookId)
        {
            //Booking bookings = null;
            Booking book = null;
            List<Booking> bklist = new List<Booking>();
            try
            {


                //cmd.CommandText = "USP_SearchPatient_142746";
                //cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd = new SqlCommand("Select * from BookingNN_OTB where @CustomerID=CustomerID", cn);

                cmd.Parameters.AddWithValue("@CustomerID", bookId);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    //bookings = new Booking();
                    dr.Read();
                   book = new Booking();
                    book.TaxiID = (int)dr[0];
                    book.CustomerID = (int)dr[1];
                    book.BookingDate = Convert.ToDateTime(dr[2]);
                    book.TripDate = Convert.ToDateTime(dr[3]);
                    book.StartTime = dr[4].ToString();
                    book.EndTime = dr[5].ToString();
                    book.SourceAddress = dr[6].ToString();
                    book.DestinationAddress = dr[7].ToString();
                   bklist.Add(book);
                }
                else
                {
                    throw new OnlineTaxiException("Record not found");
                }

            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }

            return bklist;
        }

        public List<Booking> RetriveBooking()
        {
            try
            {
                cmd = new SqlCommand("Select * from BookingNN_OTB", cn);
                //cmd = new SqlCommand("usp_Customer_OTB");
                //cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Booking book = new Booking();
                    book.TaxiID = (int)dr[0];
                    book.CustomerID = (int)dr[1];
                    book.BookingDate = Convert.ToDateTime(dr[2]);
                    book.TripDate = Convert.ToDateTime(dr[3]);
                    book.StartTime = dr[4].ToString();
                    book.EndTime = dr[5].ToString();
                    book.SourceAddress = dr[6].ToString();
                    book.DestinationAddress = dr[7].ToString();
                    booklist.Add(book);
                }
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return booklist;
        }
        }
    }
