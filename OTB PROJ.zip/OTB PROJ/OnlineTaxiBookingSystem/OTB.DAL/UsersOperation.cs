﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OTB.Entity;
using OTB.Exception;
using System.IO;

namespace OTB.DAL
{
   public class UsersOperation
    {
        static List<Users> usersList = new List<Users>();
        public static bool InsertUsers(Users users)
        {
            bool UsersInserted = false;

            try
            {
                //Adding new Users to collection
                usersList.Add(users);
                UsersInserted = true;
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return UsersInserted;
        }

        public static bool ModifyUsers(Users users)
        {
            bool UsersModified = false;

            try
            {
                for (int i = 0; i < usersList.Count; i++)
                {
                    //Searching Users
                    if (usersList[i].LoginID == users.LoginID)
                    {
                        //Modifying Employee Details
                        usersList[i].LoginID = users.LoginID;
                        usersList[i].Password = users.Password;
                        usersList[i].EmployeeID = users.EmployeeID;
                        usersList[i].CustomerID = users.CustomerID;
                        usersList[i].Role = users.Role;
                        UsersModified = true;
                    }
                }
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return UsersModified;
        }

        public static bool DeleteUsers(int loginID)
        {
            bool UsersDeleted = false;

            try
            {
                //Searching Employee
                Users users = usersList.Find(u => u.LoginID == loginID);
                if (users != null)
                {
                    //Removing Employee
                    usersList.Remove(users);
                    UsersDeleted = true;
                }
                else
                {
                    throw new OnlineTaxiException("Users with id " + loginID + " not found for deletion");
                }
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return UsersDeleted;
        }

        public static Users SearchUsers(int loginID)
        {
            Users users = null;

            try
            {
                //Searching Employee
                users = usersList.Find(u => u.LoginID == loginID);
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return users;
        }

        public static List<Users> RetrieveUsers()
        {
            return usersList;
        }
    }
}
