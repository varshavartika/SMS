﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OTB.Entity;
using OTB.Exception;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;

namespace OTB.DAL
{
   public  class TaxiOperation
    {
        SqlConnection cn = null;
       SqlCommand cmd = null;
     SqlDataReader dr = null;
        static List<Taxie> taxiList = new List<Taxie>();
        //public static bool InsertTaxi(Taxi taxi)
        //{
        //    bool taxiInserted = false;

        //    try
        //    {
        //        //Adding new Taxi to collection
        //        taxiList.Add(taxi);
        //        taxiInserted = true;
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return taxiInserted;
        //}

        //public static bool ModifyTaxi(Taxi taxi)
        //{
        //    bool taxiModified = false;

        //    try
        //    {
        //        for (int i = 0; i < taxiList.Count; i++)
        //        {
        //            //Searching Taxi
        //            if (taxiList[i].TaxiID == taxi.TaxiID)
        //            {
        //                //Modifying Employee Details
        //                taxiList[i].TaxiID = taxi.TaxiID;
        //                taxiList[i].TaxiModel = taxi.TaxiModel;
        //                taxiList[i].Color = taxi.Color;
        //                taxiList[i].RegistrationNumber= taxi.RegistrationNumber;
        //                taxiList[i].TaxiType = taxi.TaxiType;
        //                taxiModified = true;
        //            }
        //        }
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return taxiModified;
        //}

        //public static bool DeleteTaxi(int taxiID)
        //{
        //    bool taxiDeleted = false;

        //    try
        //    {
        //        //Searching Employee
        //        Taxi taxi = taxiList.Find(t => t.TaxiID == taxiID);
        //        if (taxi != null)
        //        {
        //            //Removing Employee
        //            taxiList.Remove(taxi);
        //            taxiDeleted = true;
        //        }
        //        else
        //        {
        //            throw new OnlineTaxiException("Taxi with id " + taxiID + " not found for deletion");
        //        }
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return taxiDeleted;
        //}

        //public  List<Taxie> SearchTaxi(string taxitype)
        //{
        //   Taxie taxi = null;

        //    try
        //    {
        //        //Searching Employee
        //       // taxi = taxiList.Find(t => t.TaxiID == taxiID);
        //       // Taxie taxi = new Taxie();
        //        //cmd.CommandText = "USP_SelectTaxiOTB";
        //        cmd = new SqlCommand("USP_SelectTaxiOTB", cn);
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;
        //        cn.Open();
        //        cmd.Parameters.AddWithValue("@Taxi_Type", taxitype);

               
        //       dr = cmd.ExecuteReader();
        //       if (dr.HasRows)
        //        {
        //            taxi = new Taxie();
        //            dr.Read();
        //          taxi.TaxiID = (int)dr["TaxiID"];
        //          taxi.TaxiModel = dr["TaxiModel"].ToString();
        //          taxi.Color = dr["Color"].ToString();
        //          taxi.RegistrationNumber = (int)dr["RegistrationNumber"];

        //          taxi.TaxiType = dr["TaxiType"].ToString();
        //          taxiList.Add(taxi); 
        //        }
                
        //        cmd.Connection.Close();
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return taxiList;
        //}
        ////Function to search employee record based on Student Code
        //public Patient SearchPatient_DAL(int patId)
        //{
        //    Patient pat = null;

        //    try
        //    {


        //        cmd.CommandText = "USP_SearchPatient_142746";
        //        cmd.CommandType = System.Data.CommandType.StoredProcedure;

        //        cmd.Parameters.AddWithValue("@Patientid", patId);

        //        cmd.Connection.Open();
        //        SqlDataReader dr = cmd.ExecuteReader();
        //        if (dr.HasRows)
        //        {
        //            pat = new Patient();
        //            dr.Read();
        //            pat.Patientid = (int)dr["Patientid"];
        //            pat.Patientname = dr["Patientname"].ToString();
        //            pat.Gender = dr["Gender"].ToString();
        //            pat.Indate = Convert.ToDateTime(dr["Indate"]);

        //            pat.Charge = (decimal)dr["Charge"];
        //            pat.Doctid = (int)dr["Doctid"];
        //        }
        //        else
        //        {
        //            throw new PatientException("Record not found");
        //        }
        //        cmd.Connection.Close();
        //    }
        //    catch (PatientException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return pat;
        //}
        //public static List<Taxi> RetrieveTaxi()
        //{
        //    return taxiList;
        //}
    }
}
