﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OTB.Entity;
using OTB.Exception;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;

namespace OTB.DAL
{
    public class CustomerOperation
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        List<Customer> custlist = null;

        public CustomerOperation()
        {
            string cnStr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
            cn = new SqlConnection(cnStr);
            custlist = new List<Customer>();
        }
       // static List<Customer> custList = new List<Customer>();

        public bool InsertCustomer(Customer cust)
        {
            bool custInserted = false;

            try
            {

                cmd = new SqlCommand("usp_InsertCustomer_OTB", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CustomerName", cust.CustomerName);
                cmd.Parameters.AddWithValue("@CAddress", cust.CAddress);
                cmd.Parameters.AddWithValue("@EmailID", cust.EmailID);
                cmd.Parameters.AddWithValue("@PhoneNumber", cust.PhoneNumber);
                cmd.Parameters.AddWithValue("@CPassword", cust.CPassword);

                cn.Open();
                cmd.ExecuteNonQuery();//for insert delete and update
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();

            }
            return custInserted;
        }

        public int ModifyCustomer(Customer cust)
        {
            int recordsAffected = 0;
            try
            {
                cmd = new SqlCommand("usp_UpdateCustomer_OTB", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@CustomerID", cust.CustomerID);
                cmd.Parameters.AddWithValue("@CustomerName", cust.CustomerName);
                cmd.Parameters.AddWithValue("@PhoneNumber", cust.PhoneNumber);
                cmd.Parameters.AddWithValue("@EmailID", cust.EmailID);
                cmd.Parameters.AddWithValue("@CAddress", cust.CAddress);
                // cmd.Parameters.AddWithValue("@CPassword", cust.CPassword);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();

            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        public int DeleteCustomer(int custID)
        {
            int recordsAffected = 0;

            try
            {
                cmd = new SqlCommand("usp_DeleteCustomer_OTB", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@CustomerID", custID);

                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();

            }

            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public Customer SearchCustomer(int custId)
        {
            Customer cust = null;

            try
            {


                //cmd.CommandText = "USP_SearchPatient_142746";
                //cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd = new SqlCommand("Select * from Customer_OTB where @CustomerID=CustomerID", cn);

                cmd.Parameters.AddWithValue("@CustomerID", custId);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    cust = new Customer();
                    dr.Read();
                    cust.CustomerID = (int)dr[0];
                    cust.CustomerName = dr[1].ToString();
                    cust.PhoneNumber = dr[2].ToString();
                    cust.EmailID = dr[3].ToString();
                    cust.CAddress = dr[4].ToString();
                }
                else
                {
                    throw new OnlineTaxiException("Record not found");
                }
                
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cmd.Connection.Close();
            }

            return cust;
        }

        public List<Customer> RetriveCustomer()
        {
            try
            {
                cmd = new SqlCommand("Select * from Customer_OTB", cn);
                //cmd = new SqlCommand("usp_Customer_OTB");
                //cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Customer cust = new Customer();
                    cust.CustomerID = (int)dr[0];
                    cust.CustomerName = dr[1].ToString();
                    cust.PhoneNumber = dr[2].ToString();
                    cust.EmailID = dr[3].ToString();
                    cust.CAddress = dr[4].ToString();
                    cust.CPassword = dr[5].ToString();
                    custlist.Add(cust);
                }
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }
            return custlist;
        }
    }
}

