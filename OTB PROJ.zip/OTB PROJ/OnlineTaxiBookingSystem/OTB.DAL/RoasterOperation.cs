﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OTB.Entity;
using OTB.Exception;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using OTB.Entity;
using OTB.Exception;

namespace OTB.DAL
{
   public class RoasterOperation
    {
       static List<Roaster> rstList = new List<Roaster>();
       //Connected Arch : CN,CMD,DR
       SqlConnection cn = null;
       SqlCommand cmd = null;
       SqlDataReader dr = null;

       public RoasterOperation()
       {
           string cnStr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;

           cn = new SqlConnection(cnStr);
       }


       public int InsertRoster(Roaster rst)

       {

           int n;
           try
           {

               //CODE FOR STORED PROCEDURES.............
               //cmd = new SqlCommand("insert into Employee_142938(EmpName,Gender,DOJ,DeptID,Salary) values (@EmpName,@Gender,@DOJ,@DeptID,@Salary)", cn);
               cmd = new SqlCommand("usp_InsertEmployeeRoster_OTB", cn);
               cmd.CommandType = System.Data.CommandType.StoredProcedure;
               cmd.Parameters.AddWithValue("@EmployeeID",rst.EmployeeID);
               cmd.Parameters.AddWithValue("@FromDate", rst.FromDate);
               cmd.Parameters.AddWithValue("@ToDate", rst.ToDate);
               cmd.Parameters.AddWithValue("@InTime", rst.InTime);
               cmd.Parameters.AddWithValue("@OutTime", rst.OutTime);


               cn.Open();
               n = cmd.ExecuteNonQuery();//for insert delete and update
           }
           catch (OnlineTaxiException ex)
           {
               throw ex;
           }
           finally
           {

               cn.Close();
           }

           return n;

       }



       public int ModifyRoaster(Roaster rst)
       {
           int recordsAffected = 0;

           try
           {
               cmd = new SqlCommand("usp_UpdateEmployeeRoster_OTB", cn);
               cmd.CommandType = System.Data.CommandType.StoredProcedure;

               //Adding parameters to command
              
               cmd.Parameters.AddWithValue("@EmployeeID", rst.EmployeeID);
               cmd.Parameters.AddWithValue("@FromDate", rst.FromDate);
               cmd.Parameters.AddWithValue("@ToDate", rst.ToDate);
               cmd.Parameters.AddWithValue("@InTime", rst.InTime);
               cmd.Parameters.AddWithValue("@OutTime", rst.OutTime);


               //Executing command
               cmd.Connection.Open();
               recordsAffected = cmd.ExecuteNonQuery();
               cmd.Connection.Close();
           }
           catch (OnlineTaxiException ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }

           return recordsAffected;
       }

       public int DeleteRoster(int empID)
       {
           int recordsAffected = 0;

           try
           {
               //Creating command object

               cmd = new SqlCommand("usp_DeleteEmployeeRoster_OTB", cn);
               cmd.CommandType = System.Data.CommandType.StoredProcedure;

               //Adding parameters to command
               cmd.Parameters.AddWithValue("@EmployeeID", empID);

               //Executing command
               cmd.Connection.Open();
               recordsAffected = cmd.ExecuteNonQuery();
               cmd.Connection.Close();
           }
           catch (OnlineTaxiException ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }

           return recordsAffected;
       }

       //public static Roaster SearchRoaster(int rstID)
       //{
       //    Roaster rst = null;

       //    try
       //    {
       //        //Searching Employee
       //        rst = rstList.Find(r => r.RoasterID == rstID);
       //    }
       //    catch (OnlineTaxiException ex)
       //    {
       //        throw ex;
       //    }
       //    catch (SystemException ex)
       //    {
       //        throw ex;
       //    }

       //    return rst;
       //}

       public List<Roaster> RetrieveRoaster()
       {
           List<Roaster> rstlist = new List<Roaster>();
           try
           {
              // cmd = new SqlCommand("Select * from EmployeeRoster_OTBN", cn);
               cmd = new SqlCommand("usp_SelectEmployeeRoster_OTB", cn);
               cmd.CommandType = System.Data.CommandType.StoredProcedure;
               cn.Open();
               dr = cmd.ExecuteReader();//For Select Only
               //To Retreive the record with the help of data reader
               while (dr.Read())
               {
                   Roaster rt = new Roaster();
                   rt.RoasterID = (int)dr[0];
                   rt.EmployeeID = (int)dr[1];
                   rt.FromDate = (Convert.ToDateTime(dr[2]));
                   rt.ToDate = (Convert.ToDateTime(dr[3]));
                   rt.InTime = (Convert.ToDateTime(dr[4]));
                   rt.OutTime = (Convert.ToDateTime(dr[5]));
                   
                   rstlist.Add(rt);
               }
           }
           catch (OnlineTaxiException ex)
           {
               throw ex;
           }
           catch (SystemException ex)
           {
               throw ex;
           }
           finally
           {
               dr.Close();
               cn.Close();
           }

           return rstlist;
       }
    }
}
