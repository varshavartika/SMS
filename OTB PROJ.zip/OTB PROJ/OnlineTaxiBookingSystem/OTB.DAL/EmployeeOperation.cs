﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OTB.Entity;
using OTB.Exception;
using System.IO;
using System.Data.SqlClient;
using System.Configuration;

namespace OTB.DAL
{
    public class EmployeeOperation
    {
        SqlConnection cn = null;
        SqlCommand cmd = null;
        SqlDataReader dr = null;
        List<Employee> empList = null;

        public EmployeeOperation()
        {
            string cnStr = ConfigurationManager.ConnectionStrings["cn1"].ConnectionString;
            cn = new SqlConnection(cnStr);
            empList=new List<Employee>();
        }

        public bool InsertEmployee(Employee emp)
        {
            bool empInserted = false;

            try
            {
              //  cmd = new SqlCommand("usp_InsertEmployee_OTB_142746", cn);
                cmd = new SqlCommand("usp_InsertEmployee_OTB", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
         
                cmd.Parameters.AddWithValue("@EmployeeName", emp.EmployeeName);
                cmd.Parameters.AddWithValue("@Designation", emp.Designation);
                cmd.Parameters.AddWithValue("@PhoneNumber", emp.PhoneNumber);
                cmd.Parameters.AddWithValue("@EmailID", emp.EmailID);
                cmd.Parameters.AddWithValue("@Addresss", emp.Address);
                cmd.Parameters.AddWithValue("@DrivingLicenseNumber", emp.DrivingLicenseNumber);
                cmd.Parameters.AddWithValue("@EPassword", emp.EPassword);
                cn.Open();
                cmd.ExecuteNonQuery();
               
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                cn.Close();

            }
            return empInserted;
        }

        public int ModifyEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                cmd = new SqlCommand("usp_UpdateEmployee_OTB", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@EmployeeID", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@EmployeeName", emp.EmployeeName);
                cmd.Parameters.AddWithValue("@Designation", emp.Designation);
                cmd.Parameters.AddWithValue("@PhoneNumber", emp.PhoneNumber);
                cmd.Parameters.AddWithValue("@EmailID", emp.EmailID);
                cmd.Parameters.AddWithValue("@Addresss", emp.Address);
                cmd.Parameters.AddWithValue("@DrivingLicenseNumber", emp.DrivingLicenseNumber);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public int DeleteEmployee(int empID)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object

                cmd = new SqlCommand("usp_DeleteEmployee_OTB", cn);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@EmployeeID", empID);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //public static Employee SearchEmployee(int empID)
        //{
        //    Employee emp = null;

        //    try
        //    {
        //        //Searching Employee
        //        emp = empList.Find(e => e.EmployeeID == empID);
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return emp;
        //}

        public List<Employee> RetrieveEmployee()
        {
            try
            {
                cmd = new SqlCommand("Select * from Employee_OTB", cn);
                //cmd = new SqlCommand("usp_SelectEmployee_OTB", cn);
                //cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cn.Open();
                dr = cmd.ExecuteReader();//For Select Only
                //To Retreive the record with the help of data reader
                while (dr.Read())
                {
                    Employee emp = new Employee();
                    emp.EmployeeID = (int)dr[0];
                    emp.EmployeeName = dr[1].ToString();
                    emp.Designation = dr[2].ToString();
                   emp.PhoneNumber = dr[3].ToString();
                   emp.EmailID = dr[4].ToString();
                    emp.Address = dr[5].ToString();
                    emp.DrivingLicenseNumber = dr[6].ToString();
                    emp.EPassword = dr[7].ToString();
                   empList.Add(emp);
                }
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            finally
            {
                dr.Close();
                cn.Close();
            }

            return empList;
        }
    }
}
