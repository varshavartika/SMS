﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OTB.Exception;
using OTB.Entity;
using OTB.DAL;
using System.Text.RegularExpressions;

namespace OTB.BL
{
    public class TaxiValidations
    {
        CustomerOperation custop = null;
        EmployeeOperation empop = null;
        RoasterOperation rst = null;
        BookingOperation booking = null;
        TaxiOperation tax = null;
        List<Employee> emplist = null;
        List<Roaster> rstlist = null;
        List<Customer> custlist = null;

      public TaxiValidations()
        {
            empop = new EmployeeOperation();
            custop = new CustomerOperation();
            booking = new BookingOperation();
            emplist = new List<Employee>();
            tax = new TaxiOperation();
            rst = new RoasterOperation();
            rstlist = new List<Roaster>();
            custlist = new List<Customer>();
        }

        //Employee Validations
        public static bool ValidateEmployee(Employee emp)
        {

            bool empValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
               
                if (emp.EmployeeName.Trim() == string.Empty)
                {
                    message.Append("Employee Name should be provided\n");
                    empValidated = false;
                }
                else if (!Regex.IsMatch(emp.EmployeeName, "[A-Z][a-z]+"))
                {
                    message.Append("Employee Name should start with capital alphabet and it should have alphabets only\n");
                    empValidated = false;
                }

                if (emp.PhoneNumber.Trim() == string.Empty)
                {
                    message.Append("Phone number can't be empty!\n");
                    empValidated = false;
                }
                else if (!Regex.IsMatch(emp.PhoneNumber, "[7-9][0-9]{9}"))
                {
                    message.Append("Phone number should start with 7 or 8 or 9 and it should have 10 digits\n");
                    empValidated = false;
                }


                if (emp.Designation.Trim() == string.Empty)
                {
                    message.Append("Designation can't be empty!\n");
                    empValidated = false;

                }

                if (emp.Address.Trim() == string.Empty)
                {
                    message.Append("Address can't be empty!\n");
                    empValidated = false;

                }

                if (emp.DrivingLicenseNumber.Trim() == string.Empty)
                {
                    message.Append("Driving License Number can't be empty!\n");
                    empValidated = false;

                }
                else if (!Regex.IsMatch(emp.DrivingLicenseNumber, "[A-Z][A-Z][0-9]{11}"))
                {
                    message.Append("DrivingLicense is incorrect! Please make sure you have entered the 13 characters.\n");
                    empValidated = false;
                }


                if (emp.EmailID.Trim() == string.Empty)
                {
                    message.Append("Email can't be empty!");
                    empValidated = false;
                }
                else if (!Regex.IsMatch(emp.EmailID, @"^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"))
                {
                    message.Append("Email format not correct!");
                    empValidated = false;
                }

                if (emp.EPassword.Trim() == string.Empty)
                {
                    message.Append("Password can't be empty!");
                }

                else if (!Regex.IsMatch(emp.EPassword, "[A-Za-z0-9]{5}"))
                {
                    message.Append("Password format not correct!");
                    empValidated = false;
                }

                if (empValidated == false)
                    throw new OnlineTaxiException(message.ToString());
            }
         catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empValidated;
        }

        //Employee Validations
        public static bool ValidateUpdateEmployee(Employee emp)
        {

            bool empValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {

                if (emp.EmployeeName.Trim() == string.Empty)
                {
                    message.Append("Employee Name should be provided\n");
                    empValidated = false;
                }
                else if (!Regex.IsMatch(emp.EmployeeName, "[A-Z][a-z]+"))
                {
                    message.Append("Employee Name should start with capital alphabet and it should have alphabets only\n");
                    empValidated = false;
                }

                if (emp.PhoneNumber.Trim() == string.Empty)
                {
                    message.Append("Phone number can't be empty!\n");
                    empValidated = false;
                }
                else if (!Regex.IsMatch(emp.PhoneNumber, "[7-9][0-9]{9}"))
                {
                    message.Append("Phone number should start with 7 or 8 or 9 and it should have 10 digits\n");
                    empValidated = false;
                }


                if (emp.Designation.Trim() == string.Empty)
                {
                    message.Append("Designation can't be empty!\n");
                    empValidated = false;

                }

                if (emp.Address.Trim() == string.Empty)
                {
                    message.Append("Address can't be empty!\n");
                    empValidated = false;

                }

                if (emp.DrivingLicenseNumber.Trim() == string.Empty)
                {
                    message.Append("Driving License Number can't be empty!\n");
                    empValidated = false;

                }
                else if (!Regex.IsMatch(emp.DrivingLicenseNumber, "[A-Z][A-Z][0-9]{11}"))
                {
                    message.Append("DrivingLicense is incorrect! Please make sure you have entered the 13 characters.\n");
                    empValidated = false;
                }


                if (emp.EmailID.Trim() == string.Empty)
                {
                    message.Append("Email can't be empty!");
                    empValidated = false;
                }
                else if (!Regex.IsMatch(emp.EmailID, @"^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"))
                {
                    message.Append("Email format not correct!");
                    empValidated = false;
                }

                //if (emp.EPassword.Trim() == string.Empty)
                //{
                //    message.Append("Password can't be empty!");
                //}

                //else if (!Regex.IsMatch(emp.EPassword, "[A-Za-z0-9]{5}"))
                //{
                //    message.Append("Password format not correct!");
                //    empValidated = false;
                //}

                if (empValidated == false)
                    throw new OnlineTaxiException(message.ToString());
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empValidated;
        }

        





          public static bool ValidateUpdateCustomer(Customer cust)
        {

            bool custValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {

                if (cust.CustomerName.Trim() == string.Empty)
                {
                    message.Append("Employee Name should be provided\n");
                    custValidated = false;
                }
                else if (!Regex.IsMatch(cust.CustomerName, "[A-Z][a-z]+"))
                {
                    message.Append("Employee Name should start with capital alphabet and it should have alphabets only\n");
                    custValidated = false;
                }

                if (cust.PhoneNumber.Trim() == string.Empty)
                {
                    message.Append("Phone number can't be empty!\n");
                    custValidated = false;
                }
                else if (!Regex.IsMatch(cust.PhoneNumber, "[7-9][0-9]{9}"))
                {
                    message.Append("Phone number should start with 7 or 8 or 9 and it should have 10 digits\n");
                    custValidated = false;
                }


               

                if (cust.CAddress.Trim() == string.Empty)
                {
                    message.Append("Address can't be empty!\n");
                    custValidated = false;

                }

                //if (emp.DrivingLicenseNumber.Trim() == string.Empty)
                //{
                //    message.Append("Driving License Number can't be empty!\n");
                //    empValidated = false;

                //}
                //else if (!Regex.IsMatch(emp.DrivingLicenseNumber, "[A-Z][A-Z][0-9]{11}"))
                //{
                //    message.Append("DrivingLicense is incorrect! Please make sure you have entered the 13 characters.\n");
                //    empValidated = false;
                //}


                if (cust.EmailID.Trim() == string.Empty)
                {
                    message.Append("Email can't be empty!");
                    custValidated = false;
                }
                else if (!Regex.IsMatch(cust.EmailID, @"^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"))
                {
                    message.Append("Email format not correct!");
                    custValidated = false;
                }

                //if (emp.EPassword.Trim() == string.Empty)
                //{
                //    message.Append("Password can't be empty!");
                //}

                //else if (!Regex.IsMatch(emp.EPassword, "[A-Za-z0-9]{5}"))
                //{
                //    message.Append("Password format not correct!");
                //    empValidated = false;
                //}

                if (custValidated == false)
                    throw new OnlineTaxiException(message.ToString());
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custValidated;
        }
        //customer validations

        public static bool ValidateCustomer(Customer cust)
        {
            bool custValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {

                if (cust.CustomerName.Trim() == string.Empty)
                {
                    message.Append("Customer Name should be provided\n");
                    custValidated = false;
                }
                else if (!Regex.IsMatch(cust.CustomerName, "[A-Z][a-z]+"))
                {
                    message.Append("Customer Name should start with capital alphabet and it should have alphabets only\n");
                    custValidated = false;
                }

              
                if (cust.PhoneNumber.Trim() == string.Empty)
                {
                    message.Append("Phone number can't be empty!\n");
                    custValidated = false;
                }
                else if (!Regex.IsMatch(cust.PhoneNumber, "[7-9][0-9]{9}"))
                {
                    message.Append("Phone number should start with 7 or 8 or 9 and it should have 10 digits\n");
                    custValidated = false;
                }

               if (cust.CAddress.Trim() == string.Empty)
                {
                    message.Append("Address can't be empty!\n");
                    custValidated = false;

                }

             if (cust.EmailID.Trim() == string.Empty)
                {
                    message.Append("Email can't be empty!");
                    custValidated = false;
                }
                else if (!Regex.IsMatch(cust.EmailID, @"^([0-9a-zA-Z]([-\.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$"))
                {
                    message.Append("Email format not correct!");
                    custValidated = false;
                }

             if (cust.CPassword.Trim() == string.Empty)
             {
                 message.Append("Password can't be empty!");
             }

             else if (!Regex.IsMatch(cust.CPassword, "[A-Za-z0-9]{5}"))
             {
                 message.Append("Password format not correct!");
                 custValidated = false;
             }

                if (custValidated == false)
                    throw new OnlineTaxiException(message.ToString());
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custValidated;
        }

        //roster validations
        public static bool ValidaterRoster(Roaster rost)
        {
            bool rostValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //if (rost.EmployeeID < 100000 || rost.EmployeeID > 999999)
                //{
                //    message.Append("Employee ID should be 6 digits\n");
                //    rostValidated = false;
                //}

                //if (rost.RoasterID< 100000 || rost.RoasterID > 999999)
                //{
                //    message.Append("Roster ID should be 6 digits\n");
                //    rostValidated = false;
                //}

                //if (rost.FromDate.ToString()==string.Empty)
                //{

                //    message.Append("Date can't be empty!\n");
                //    rostValidated = false;
                //}
                
                //if (rost.ToDate.ToString() == string.Empty)
                //{

                //    message.Append("Date can't be empty!\n");
                //    rostValidated = false;
                //}

                if (rost.InTime.ToString() == string.Empty)
                {

                    message.Append("In time can't be empty!\n");
                    rostValidated = false;
                }
                if (rost.OutTime.ToString() == string.Empty)
                {

                    message.Append("Out time can't be empty!\n");
                    rostValidated = false;
                }

                if (rostValidated == false)
                    throw new OnlineTaxiException(message.ToString());
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rostValidated;
        }

        //Insert Roster
        public  int InsertEmployeeRoster(Roaster rsti)
        {

            int recordsAffected = 0;

            try
            {
                if (ValidaterRoster(rsti))
                {
                    recordsAffected = rst.InsertRoster(rsti);
                }
                else
                    throw new OnlineTaxiException("Please provide valid Roster Information");
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }
        //Retrieve Roster
        public List<Roaster> RetrieveRoster()
        {
            try
            {
                rstlist = rst.RetrieveRoaster();
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return rstlist;
        }

        //update roster

        public int ModifyRoster(Roaster rste)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidaterRoster(rste))
                {
                    recordsAffected = rst.ModifyRoaster(rste);
                }
                else
                    throw new OnlineTaxiException("Please provide valid roster Information");
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //delete roster

        public int DeleteRoster(int empID)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = rst.DeleteRoster(empID);
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

//credentials validation
        public static bool ValidateUser(Users user)
        {
            bool userValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
               
               
                if (user.Password == string.Empty)
                {

                    message.Append("Password can't be empty!\n");
                    userValidated = false;
                }

                if (user.LoginID.ToString() == string.Empty)
                {

                    message.Append("Log in can't be empty!\n");
                    userValidated = false;
                }
                if(user.Role == string.Empty)
                {
                    message.Append("Role can't be empty!\n");
                    userValidated = false;
                }


                 if (userValidated == false)
                    throw new OnlineTaxiException(message.ToString());
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return userValidated;
        }

        //EMPLOYEE METHOD VALIDATIONS

        public bool InsertEmployee(Employee emp)
        {
           
           bool empInserted = false;

            try
            {
                if (ValidateEmployee(emp))
                {
                    empInserted = empop.InsertEmployee(emp);
                }
                else
                {
                    throw new OnlineTaxiException("Employee Details are not valid");
                }
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return empInserted;
        }

        public int ModifyEmployee(Employee emp)
        {
            int recordsAffected = 0;

            try
            {
                if (ValidateUpdateEmployee(emp))
                {
                    recordsAffected = empop.ModifyEmployee(emp);
                }
                else
                    throw new OnlineTaxiException("Please provide valid patient Information");
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        public int DeleteEmployee(int empID)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = empop.DeleteEmployee(empID);
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //public static Employee SearchEmployee(int empID)
        //{
        //    Employee emp = null;

        //    try
        //    {
        //        emp = EmployeeOperation.SearchEmployee(empID);
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return emp;
        //}

        public List<Employee> RetrieveEmployee()
        {
            try
            {
                emplist = empop.RetrieveEmployee();
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return emplist;
        }



        //method validation customers

        public bool InsertCustomer(Customer cust)
        {

           
            bool custInserted = false;

            try
            {
                if (ValidateCustomer(cust))
                {
                    custInserted = custop.InsertCustomer(cust);
                }
                else
                {
                    throw new OnlineTaxiException("Customer Details are not valid");
                }
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return custInserted;
        }

        //public static bool ModifyCustomer(Customer cust)
        //{
        //    bool custModified = false;

        //    try
        //    {
        //        if (ValidateCustomer(cust))
        //        {
        //            custModified = CustomerOperation.ModifyCustomer(cust);
        //        }
        //        else
        //        {
        //            throw new OnlineTaxiException("Customer Details are not valid for modification");
        //        }
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }


        public int ModifyCustomer(Customer cust)
        {
            int recordsAffected = 0;
            try
            {
                if (ValidateUpdateCustomer(cust))
                {
                    recordsAffected = custop.ModifyCustomer(cust);
                }
                else
                    throw new OnlineTaxiException("Please provide valid customer details");
            }

            catch(OnlineTaxiException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }


   public int DeleteCustomer(int custID)
        {
            int recordsAffected = 0;

            try
            {
                recordsAffected = custop.DeleteCustomer(custID);
            }
       catch(OnlineTaxiException ex)
            {
                throw ex;
            }
       catch(SystemException ex)
            {
                throw ex;
            }
            return recordsAffected;
        }

        //    return custModified;
        //}

        //public static bool DeleteCustomer(int custID)
        //{
        //    bool custDeleted = false;

        //    try
        //    {
        //        custDeleted = CustomerOperation.DeleteCustomer(custID);
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return custDeleted;
        //}

   public Customer SearchCustomer(int custId)
   {
       Customer cust = null;

       try
       {
           cust = custop.SearchCustomer(custId);
       }
       catch (OnlineTaxiException ex)
       {
           throw ex;
       }
       catch (SystemException ex)
       {
           throw ex;
       }

       return cust;
   }

        public List<Customer> RetrieveCustomer()
        {
            List<Customer> custList = null;

            try
            {
                custList = custop.RetriveCustomer();
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }


            return custList;
        }


        //Method VALIDATIONS for TAXI BOOKING

        //        public static bool InsertTaxi(Taxi taxi)
        //{
        //    bool taxiInserted = false;

        //    try 
        //    {
        //        if (ValidateTaxi(taxi))
        //        {
        //            taxiInserted = TaxiOperation.InsertTaxi(taxi);
        //        }
        //        else
        //        {
        //            throw new OnlineTaxiException("Taxi Details are not valid");
        //        }
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return taxiInserted;
        //}

        //public static bool ModifyEmployee(Employee emp)
        //{
        //    bool empModified = false;

        //    try
        //    {
        //        if (ValidateEmployee(emp))
        //        {
        //            empModified = EmployeeOperations.ModifyEmployee(emp);
        //        }
        //        else
        //        {
        //            throw new EmployeeException("Employee Details are not valid for modification");
        //        }
        //    }
        //    catch (EmployeeException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return empModified;
        //}

        //public static bool DeleteEmployee(int empID)
        //{
        //    bool empDeleted = false;

        //    try
        //    {
        //        empDeleted = EmployeeOperations.DeleteEmployee(empID);
        //    }
        //    catch (EmployeeException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return empDeleted;
        //}


        //public  List<Taxie> SearchTaxi(string taxitype)
        //{
        //    List<Taxie> taxi = new List<Taxie>();
        //    tax = new TaxiOperation();
        //    try
        //    {
        //        taxi = tax.SearchTaxi(taxitype);
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return taxi;
        //}

        //public static List<Taxi> RetrieveTaxi()
        //{
        //    List<Taxi> taxiList = null;

        //    try
        //    {
        //        taxiList = TaxiOperation.RetrieveTaxi();
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }


        //    return taxiList;
        //}

        //VALIDATIONS FOR USER METHODS


        //public static bool InsertUser(Users user)
        //{
        //    bool userInserted = false;

        //    try
        //    {
        //        if (ValidateUser(user))
        //        {
        //            userInserted = UsersOperation.InsertUsers(user);
        //        }
        //        else
        //        {
        //            throw new OnlineTaxiException("User Details are not valid");
        //        }
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return userInserted;
        //}

        //public static bool ModifyUsers(Users user)
        //{
        //    bool userModified = false;

        //    try
        //    {
        //        if (ValidateUser(user))
        //        {
        //            userModified = UsersOperation.ModifyUsers(user);
        //        }
        //        else
        //        {
        //            throw new OnlineTaxiException("User Details are not valid for modification");
        //        }
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return userModified;
        //}

        //public static bool DeleteUsers(int loginID)
        //{
        //    bool loginIDDeleted = false;

        //    try
        //    {
        //        loginIDDeleted = UsersOperation.DeleteUsers(loginID);
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return loginIDDeleted;
        //}

        //public static Users SearchUsers(int loginID)
        //{
        //    Users user = null;

        //    try
        //    {
        //       user = UsersOperation.SearchUsers(loginID);
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }

        //    return user;
        //}

        //public static List<Users> RetrieveUsers()
        //{
        //    List<Users> userList = null;

        //    try
        //    {
        //        userList = UsersOperation.RetrieveUsers();
        //    }
        //    catch (OnlineTaxiException ex)
        //    {
        //        throw ex;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw ex;
        //    }


        //    return userList;
        //}

        public bool InsertBooking(Booking book)
        {

            bool bookInserted = false;

            try
            {
                
                    bookInserted = booking.InsertBooking(book);
                
               
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bookInserted;
        }
        public List<Booking> RetrieveBooking()
        {
            List<Booking> bookList = null;

            try
            {
                bookList = booking.RetriveBooking();
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }


            return bookList;
        }
        public List<Booking> SearchBooking(int bookId)
        {
            List<Booking> bklist = new List<Booking>(); 

            try
            {
                bklist = booking.SearchBooking(bookId);
            }
            catch (OnlineTaxiException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return bklist;
        }

    }
       

    }

