﻿ using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace storemanagmentsystem
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                // FindUserName();
                //ddldesgn.Items.Insert(0, "-----SELECT------");
                //ddlename.Items.Insert(0, "-----SELECT------");
                BindDDL();
                bindStocDdl();
                gridBind();


            }
        }
        string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        public void BindDDL()
        {
            //string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand(" SELECT * FROM dtable ", con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);

            ddldesgn.DataSource = ds.Tables[0];

            ddldesgn.DataTextField = "D_NAME";
            ddldesgn.DataValueField = "D_ID";

            ddldesgn.DataBind();
            ddldesgn.Items.Insert(0, "-----SELECT------");

            con.Close();


        }
        public void bindStocDdl()
        {
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand("select * from etable et join stocknamentry st on et.STOCK_ID=st.SId", con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            ddlstockname.DataSource = ds.Tables[0];
            ddlstockname.DataTextField = "SName";
            ddlstockname.DataValueField = "SId";

            ddlstockname.DataBind();

            ddlstockname.Items.Insert(0, "-----SELECT------");


            con.Close();
        }




        protected void ddldesgn_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand(" SELECT *from stable where DESIGNATION=" + ddldesgn.SelectedValue, con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            ddlename.DataSource = ds.Tables[0];

            ddlename.DataTextField = "EMPLOYEE_NAME";
            ddlename.DataValueField = "EMPLOYEE_ID";

            ddlename.DataBind();

            con.Close();
        }






        protected void ddlmonth_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void ddlyear_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand("insert into issuetable(EMPID,STOCKID,QUANTITY,MONTH,YEAR) values (@EMPID,@STOCKID,@QUANTITY,@MONTH,@YEAR)", con);
            cmd.Parameters.AddWithValue("@EMPID", ddlename.SelectedValue);
            cmd.Parameters.AddWithValue("@YEAR", ddlyear.SelectedValue);
            cmd.Parameters.AddWithValue("@STOCKID", ddlstockname.SelectedValue);
            cmd.Parameters.AddWithValue("@QUANTITY", txtquantity.Text);
            cmd.Parameters.AddWithValue("@MONTH", ddlmonth.SelectedValue);
            con.Open();
            int x = 0;
            x = cmd.ExecuteNonQuery();
            if (x > 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('submit successfully');", true);
            }
            con.Close();
            gridBind();

        }





        public void gridBind()
        {
            string conn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(conn);
            string selectdata = "SELECT st.EMPLOYEE_ID,st.EMPLOYEE_NAME, Stke.SId,Stke.SName,Isutbl.QUANTITY,dt.D_NAME,Isutbl.MONTH,Isutbl.YEAR FROM issuetable Isutbl JOIN stable st on st.EMPLOYEE_ID=Isutbl.EMPID JOIN stocknamentry Stke on Stke.SId=Isutbl.STOCKID JOIN dtable dt on dt.D_ID=st.DESIGNATION  WHERE st.EMPLOYEE_ID='"+ ddlename.SelectedValue+"'";
            SqlCommand cmd = new SqlCommand(selectdata, con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            gridview1.DataSource = ds.Tables[0];
            gridview1.DataBind();
            con.Close();
        }

      

        protected void gridview1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gridview1.PageIndex = e.NewPageIndex;
            gridBind();

        }

        protected void ddlstockname_SelectedIndexChanged(object sender, EventArgs e)
        {
            string conn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(conn);
            string selectdata = "SELECT isd.STOCKID, (et.QUANTITY-sum(isd.QUANTITY)) as total FROM etable et JOIN stocknamentry stk on stk.SId=et.STOCK_ID join issuetable isd on isd.STOCKID=et.STOCK_ID where isd.STOCKID='" + Convert.ToString(ddlstockname.SelectedValue) + "' group by isd.STOCKID,et.QUANTITY ";
            SqlCommand cmd = new SqlCommand(selectdata, con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                lblqwnty.Text = ds.Tables[0].Rows[0][1].ToString();
            }
            else
            {


            }

        }

      

       
      

       
    }
}
