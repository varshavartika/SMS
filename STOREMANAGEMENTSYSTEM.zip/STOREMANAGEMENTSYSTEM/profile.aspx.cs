﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace storemanagmentsystem
{
    public partial class profile : System.Web.UI.Page
    {
        DataSet ds;
        string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

                getProfile();
                lblid.Text = ds.Tables[0].Rows[0][0].ToString();
                lblname.Text = ds.Tables[0].Rows[0][1].ToString();
                lbldes.Text = ds.Tables[0].Rows[0][5].ToString();
                lbleid.Text = ds.Tables[0].Rows[0][2].ToString();
                lbluname.Text = ds.Tables[0].Rows[0][3].ToString();
                lblcon.Text = ds.Tables[0].Rows[0][4].ToString();


            }

        }
        public void getProfile()
        {
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand("select stable.EMPLOYEE_ID, stable.EMPLOYEE_NAME,stable.EMAIL_ID,stable.USER_NAME,stable.CONTACT_NO,dtable.D_NAME from stable join dtable on stable.DESIGNATION=dtable.D_ID where [USER_NAME]='" + Convert.ToString(Session["username"]) + "'", con);
            con.Open();
            ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //Session["Userdata"] = ds.Tables];
            Session["Userdata"] = ds;
        }

        protected void lnledit_Click(object sender, EventArgs e)
        {
            BindDDL();

            txte_id.Visible = true;
            ddldes.Visible = true;
            txte_name.Visible = true;
            ddldes.Visible = true;
            txtemail.Visible = true;
            txtusername.Visible = true;
            txtcontact.Visible = true;
            lblid.Visible = false;
            lblname.Visible = false;
            lbldes.Visible = false;
            lbleid.Visible = false;
            lbluname.Visible = false;
            lblcon.Visible = false;
            txte_id.Text = lblid.Text;
            txte_id.Enabled = true;
            txte_name.Enabled = true;
            txtusername.Enabled = false;
            ddldes.Enabled = false;


            txte_name.Text = lblname.Text;
            ddldes.SelectedItem.Text = lbldes.Text;
            txtemail.Text = lbleid.Text;
            txtusername.Text = lbluname.Text;
            txtcontact.Text = lblcon.Text;
            

            btnupdate.Visible = true;


            lnledit.Visible = false;
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            //public void updateprofile()
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand("update stable set CONTACT_NO=@CONTACT_NO,EMPLOYEE_ID=@EMPLOYEE_ID,EMPLOYEE_NAME=@EMPLOYEE_NAME, EMAIL_ID=@EMAIL_ID where USER_NAME='" + Convert.ToString(Session["username"]) + "'", con);
            cmd.Parameters.AddWithValue("@CONTACT_NO", txtcontact.Text);
            cmd.Parameters.AddWithValue("@EMPLOYEE_ID", txte_id.Text);
            cmd.Parameters.AddWithValue("@EMPLOYEE_NAME", txte_name.Text);
            
            cmd.Parameters.AddWithValue("@EMAIL_ID", txtemail.Text);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            getProfile();
            ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('updated Successfully');", true);
            txte_id.Visible = false;
            ddldes.Visible = false;
            txte_name.Visible = false;
            ddldes.Visible = false;
            txtemail.Visible = false;
            txtusername.Visible = false;
            txtcontact.Visible = false;
            lblid.Visible = true;
            lblname.Visible = true;
            lbldes.Visible = true;
            lbleid.Visible = true;
            lbluname.Visible = true;
            lblcon.Visible = true;
            btnupdate.Visible = false;


            lnledit.Visible = true;

            con.Close();
        }
        protected void ddldes_SelectedIndexChanged(object sender, EventArgs e)
        {



        }
        public void BindDDL()
        {
            //string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand(" SELECT * FROM dtable ", con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            ddldes.DataSource = ds.Tables[0];

            ddldes.DataTextField = "D_NAME";
            ddldes.DataValueField = "D_ID";
            ddldes.DataBind();
            con.Close();


        }


    }
}
