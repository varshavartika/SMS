﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace storemanagmentsystem
{
    public partial class designation : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                gridBind();
            }


        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            string conn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("insert into dtable(D_NAME)values(@D_NAME)", con);
            cmd.Parameters.AddWithValue("@D_NAME", txtD_NAME.Text);
            con.Open();
            int x = 0;
            x = cmd.ExecuteNonQuery();
            con.Close();
            if (x > 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('submit Successfully');", true);
            }
            {

                gridBind();
            }

        }
        public void gridBind()
        {
            string conn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("SELECT * FROM dtable ORDER BY D_NAME", con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            gridview1.DataSource = ds.Tables[0];
            gridview1.DataBind();
            con.Close();
        }
        public void FindDesignation()
        {
            string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand(" SELECT D_NAME from dtable where D_NAME='" + txtD_NAME.Text + "' ", con);
            con.Open();
            string DNm = (string)cmd.ExecuteScalar();
            if (DNm != null)
            {
                Label1.Visible = true;
                Label1.Text = DNm + " is already exist";
                txtD_NAME.Text = "";
                txtD_NAME.Focus();
            }
            else
            {

                Label1.Visible = false;

            }

            con.Close();


        }


        

        protected void txtD_NAME_TextChanged(object sender, EventArgs e)
        {
            FindDesignation();

        }

        protected void gridview1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gridview1.PageIndex = e.NewPageIndex;
            gridBind();

        }

       
    }


}


