﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace storemanagmentsystem
{
    public partial class storentry : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindDDL();
                gridBind();
            }
        }
        string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        //SqlDataReader dr = new SqlDataReader();


        public void BindDDL()
        {
            //string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand(" SELECT * FROM stocknamentry ", con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            ddlSTOCK_ID.DataSource = ds.Tables[0];
            ddlSTOCK_ID.DataTextField = "SName";
            ddlSTOCK_ID.DataValueField = "SId";
            ddlSTOCK_ID.DataBind();
            con.Close();
            gridBind();
        }
        public void FindStock()
        {
            //string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;




        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if ((ddlMONTHS.SelectedValue == Convert.ToString(DateTime.Now.Month)) && (ddlyear.SelectedItem.Text == Convert.ToString(DateTime.Now.Year)))
            {

                SqlConnection con = new SqlConnection(connn);
                string str = "select count(SE_ID) as SE_ID from etable where MONTH='" + ddlMONTHS.SelectedItem.Text + "' AND  STOCK_ID='" + ddlSTOCK_ID.SelectedValue + "'";
              //  YEAR='" + ddlyear.SelectedItem.Text + "'
                SqlCommand cmd = new SqlCommand(str, con);
                //SqlCommand cmd = new SqlCommand(" SELECT USER_NAME from stable where USER_NAME='" + TxtUSER_NAME.Text + "' ", con);
                con.Open();
                int i = 0;
                i = (int)cmd.ExecuteScalar();
                con.Close();
                if (i > 0)
                {
                    Label1.Visible = true;
                    Label1.Text = "This item is already exist";
                    clear();
                    //TxtUSER_NAME.Text = "";
                    //TxtUSER_NAME.Focus();
                }
                else
                {

                    Label1.Visible = false;
                    cmd = new SqlCommand("insert into etable(MONTH,YEAR,STOCK_Name,STOCK_ID,QUANTITY) values (@MONTH,@YEAR,@STOCK_Name,@STOCK_ID,@QUANTITY)", con);

                    cmd.Parameters.AddWithValue("@MONTH", ddlMONTHS.SelectedItem.Text);
                    cmd.Parameters.AddWithValue("@YEAR", ddlyear.SelectedItem.Text);
                    cmd.Parameters.AddWithValue("@STOCK_Name", ddlSTOCK_ID.SelectedItem.Text);
                    cmd.Parameters.AddWithValue("@STOCK_ID", ddlSTOCK_ID.SelectedValue);
                    cmd.Parameters.AddWithValue("@QUANTITY", txtqnty.Text);



                    con.Open();
                    int x = 0;
                    x = cmd.ExecuteNonQuery();
                    if (x > 0)
                    {
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('submit Successfully');", true);
                    }
                    clear();


                    con.Close();

                    gridBind();
                }






                //SqlConnection con = new SqlConnection(connn);

            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('please select valid month and year');", true);
            }
        }

        protected void ddlSTOCK_ID_SelectedIndexChanged(object sender, EventArgs e)
        {
            // FindStock();
        }
        public void clear()
        {
            ddlMONTHS.SelectedIndex = 0;
            ddlyear.SelectedIndex = 0;
            ddlSTOCK_ID.SelectedIndex = 0;
            txtqnty.Text = "";

        }
        public void gridBind()
        {
            string conn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from etable ", con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            GridView1.DataSource = ds.Tables[0];
            GridView1.DataBind();
            con.Close();

        }

        protected void txtqnty_TextChanged(object sender, EventArgs e)
        {
          

        }

        protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            gridBind();
        }

        

       

       
    }
}





        
