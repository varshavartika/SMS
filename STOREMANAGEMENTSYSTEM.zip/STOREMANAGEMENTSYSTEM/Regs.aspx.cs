﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;

namespace storemanagmentsystem
{
    public partial class Regs : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindDDL();
                // FindUserName();
            }

        }
        string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;


        protected void btnRegister_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(connn);
            if (ddlDESIGNATION.SelectedIndex != 0)
            {

                SqlCommand cmd = new SqlCommand("insert into stable(EMPLOYEE_ID,EMPLOYEE_NAME,DESIGNATION,EMAIL_ID,USER_NAME,PASSWORD,CONFIRM_PASSWORD,CONTACT_NO,LOGIN_TYPE) values (@EMPLOYEE_ID,@EMPLOYEE_NAME,@DESIGNATION,@EMAIL_ID,@USER_NAME,@PASSWORD,@CONFIRM_PASSWORD,@CONTACT_NO,@LOGIN_TYPE)", con);

                cmd.Parameters.AddWithValue("@EMPLOYEE_ID", TxtEMPLOYEE_ID.Text);
                cmd.Parameters.AddWithValue("@EMPLOYEE_NAME", txtEMPLOYEE_NAME.Text);
                cmd.Parameters.AddWithValue("@DESIGNATION", ddlDESIGNATION.SelectedValue);
                cmd.Parameters.AddWithValue("@EMAIL_ID", txtEMAIL_ID.Text);


                cmd.Parameters.AddWithValue("@USER_NAME", TxtUSER_NAME.Text);
                cmd.Parameters.AddWithValue("@PASSWORD", txtPASSWORD.Text);
                cmd.Parameters.AddWithValue("@CONFIRM_PASSWORD", txtCONFIRM_PASSWORD.Text);
                cmd.Parameters.AddWithValue("@CONTACT_NO", txtCONTACT_NO.Text);
                cmd.Parameters.AddWithValue("@LOGIN_TYPE", "U");
                con.Open();
                int x = 0;
                x = cmd.ExecuteNonQuery();
                if (x > 0)
                {


                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('submit Successfully');", true);
                    Response.Redirect("login.aspx");

                }

            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('Please Select Designation!!');", true);
            }

            con.Close();
            //gridBind();
        }
        public void BindDDL()
        {
            //string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand(" SELECT * FROM dtable ", con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            ddlDESIGNATION.DataSource = ds.Tables[0];

            ddlDESIGNATION.DataTextField = "D_NAME";
            ddlDESIGNATION.DataValueField = "D_ID";
            ddlDESIGNATION.DataBind();
            con.Close();


        }
        public void FindUserName()
        {
            //string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand(" SELECT USER_NAME from stable where USER_NAME='" + TxtUSER_NAME.Text + "' ", con);
            con.Open();
            string usrNm = (string)cmd.ExecuteScalar();
            if (usrNm != null)
            {
                lblMessage.Visible = true;
                lblMessage.Text = usrNm+" is already exist";
                TxtUSER_NAME.Text = "";
                TxtUSER_NAME.Focus();
            }
            else
            {

              lblMessage.Visible = false;

            }

            con.Close();


        }

        protected void TxtUSER_NAME_TextChanged(object sender, EventArgs e)
        {
            FindUserName();
        }

    }
}