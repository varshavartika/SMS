﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;



namespace storemanagmentsystem
{

    public partial class login : System.Web.UI.Page
    {
        string Islogin = "0";
        DataSet ds;
        string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {


                // FindUserName();
            }

        }
        public void ConnectionDatabse()
        {

            SqlConnection con = new SqlConnection(connn);

        }
        public void GetUserDetails()
        {
            //string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand("SELECT USER_NAME,PASSWORD,LOGIN_TYPE FROM stable where USER_NAME='" + txtuserid.Text + "'", con);
            con.Open();
            ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //Session["Userdata"] = ds.Tables];
            if (ds.Tables[0].Rows.Count > 0)
            {
                Session[Islogin] = 1;
                Session["Userdata"] = ds;
                Session["username"] = ds.Tables[0].Rows[0][0].ToString();
                Session["LOGIN_TYPE"] = ds.Tables[0].Rows[0][2].ToString();

            }
            else
            {

            }




        }

        

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Regs.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            GetUserDetails();
            if (ds.Tables[0].Rows.Count > 0)
            {
                if (txtuserid.Text == ds.Tables[0].Rows[0][0].ToString() && txtpass.Text == ds.Tables[0].Rows[0][1].ToString())
                {
                    if (txtuserid.Text == "Admin")
                    {

                        Response.Redirect("profile.aspx");
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('submit Successfully');", true);
                    }
                    else
                    {
                        Response.Redirect("userprofile.aspx");
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('submit Successfully');", true);

                    }
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('invalid username or password');", true);
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('invalid username or password');", true);
            }
        }

        

        

        
       

    }


}