﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Data;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

namespace STOREMS
{
    public partial class changepassuser : System.Web.UI.Page
    {
        DataSet ds;
        string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
            }
        }


        protected void Btnsubmit_Click(object sender, EventArgs e)
        {


            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand("SELECT USER_NAME,PASSWORD FROM stable where USER_NAME='" + Convert.ToString(Session["username"]) + "'", con);

            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            if (TextBox1.Text == Convert.ToString(ds.Tables[0].Rows[0][1]))
            {
                con.Open();

                cmd = new SqlCommand("update  stable set PASSWORD='" + TextBox2.Text + "' where USER_NAME='" + Convert.ToString(Session["username"]) + "'", con);

                int i = 0;
                i = cmd.ExecuteNonQuery();
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert(' password updated');", true);
                con.Close();

            }
            else
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert(' password  not updated');", true);
            }




        }
    }
}