﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;


namespace STOREMS
{
    public partial class userreport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            gridBind();
        }
        public void gridBind()
        {
            string conn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(conn);
            string selectdata = "SELECT stk.SName,isd.QUANTITY,isd.MONTH  FROM issuetable isd JOIN stocknamentry stk on stk.SId=isd.STOCKID JOIN stable stb on stb.EMPLOYEE_ID=isd.EMPID where stb.USER_NAME='" + Convert.ToString(Session["username"]) + "' AND isd.MONTH ='"+ DropDownList1.SelectedItem.Text+ "' ";

            SqlCommand cmd = new SqlCommand(selectdata, con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            gridview1.DataSource = ds.Tables[0];
            gridview1.DataBind();
            con.Close();
        }

        protected void gridview1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}