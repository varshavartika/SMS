﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Web.Configuration;

namespace storemanagmentsystem
{
    public partial class stock : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                gridBind();
            }

        }
        public void FindStock()
        {
            string connn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(connn);
            SqlCommand cmd = new SqlCommand(" SELECT SName from stocknamentry where SName='" + TextBox2.Text + "' ", con);
            con.Open();
            string SNm = (string)cmd.ExecuteScalar();
            if (SNm != null)
            {
                Label1.Visible = true;
                Label1.Text = SNm + " is already exist";
                TextBox2.Text = "";
                TextBox2.Focus();
            }
            else
            {

                Label1.Visible = false;

            }

            con.Close();


        }

       
        public void gridBind()
        {
            string conn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("SELECT * FROM stocknamentry", con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            gridview1.DataSource = ds.Tables[0];
            gridview1.DataBind();
            con.Close();
        }

        protected void gridview1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {
            FindStock();
        }

        protected void btnsubmit_Click1(object sender, EventArgs e)
        {
            string conn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("insert into stocknamentry(SName)values(@SName)", con);
            cmd.Parameters.AddWithValue("@SName", TextBox2.Text);
            con.Open();
            int x = 0;
            x = cmd.ExecuteNonQuery();
            con.Close();
            if (x > 0)
            {
                ScriptManager.RegisterStartupScript(this, this.GetType(), "script", "alert('submit Successfully');", true);
            }
            {

                gridBind();
            }
        }

        protected void gridview1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gridview1.PageIndex = e.NewPageIndex;
            gridBind();
        }

   

       
    }
}
        
    
