﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
namespace storemanagmentsystem
{
    public partial class adminreport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //gridbind();
            }
        }
            public void gridBind()
        {
            string conn = WebConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            SqlConnection con = new SqlConnection(conn);
            string selectdata = "SELECT st.EMPLOYEE_ID,st.EMPLOYEE_NAME,st.CONTACT_NO,st.EMAIL_ID, Stke.SId,Stke.SName,Isutbl.QUANTITY,dt.D_NAME,Isutbl.MONTH FROM issuetable Isutbl JOIN stable st on st.EMPLOYEE_ID=Isutbl.EMPID JOIN stocknamentry Stke on Stke.SId=Isutbl.STOCKID JOIN dtable dt on dt.D_ID=st.DESIGNATION  WHERE Isutbl.MONTH='" + DropDownList1.SelectedItem.Text + "'";
            SqlCommand cmd = new SqlCommand(selectdata, con);
            con.Open();
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            gridview1.DataSource = ds.Tables[0];
          gridview1.DataBind();
            con.Close();
        }

        protected void txtempid_TextChanged(object sender, EventArgs e)
        {
            //gridBind();
        }

        //protected void SUBMIT_Click(object sender, EventArgs e)
        //{
        //    gridBind();

        //}

        protected void Button1_Click(object sender, EventArgs e)
        {
            gridBind();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("report link.aspx");
        }

       

        protected void gridview1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gridview1.PageIndex = e.NewPageIndex;
            gridBind();
        }

     
       
       

       

       

    }
}



  